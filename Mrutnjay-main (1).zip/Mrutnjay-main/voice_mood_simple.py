import numpy as np
import librosa
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

class VoiceMoodAnalyzer:
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.mood_labels = {
            0: "Happy",
            1: "Sad", 
            2: "Angry",
            3: "Calm",
            4: "Excited",
            5: "Neutral"
        }
        self.feature_dim = None
        
    def extract_mood_features(self, audio_path, sr=22050):
        """
        Extract simplified mood-related features from audio
        """
        try:
            # Load audio
            y, sr = librosa.load(audio_path, sr=sr)
            
            # Remove silence for better analysis
            y_trimmed, _ = librosa.effects.trim(y, top_db=20)
            
            features = []
            
            # 1. Basic pitch features
            try:
                f0 = librosa.yin(y_trimmed, fmin=50, fmax=400)
                f0_clean = f0[f0 > 0]  # Remove unvoiced frames
                if len(f0_clean) > 0:
                    features.append(float(np.mean(f0_clean)))           # Average pitch
                    features.append(float(np.std(f0_clean)))            # Pitch variation
                    features.append(float(np.max(f0_clean) - np.min(f0_clean))) # Pitch range
                else:
                    features.extend([0.0, 0.0, 0.0])
            except:
                features.extend([0.0, 0.0, 0.0])
            
            # 2. Energy features
            rms = librosa.feature.rms(y=y_trimmed)[0]
            features.append(float(np.mean(rms)))              # Average energy
            features.append(float(np.std(rms)))               # Energy variation
            features.append(float(np.max(rms)))               # Peak energy
            
            # 3. Tempo
            try:
                tempo, _ = librosa.beat.beat_track(y=y_trimmed, sr=sr)
                features.append(float(tempo))
            except:
                features.append(120.0)  # Default tempo
            
            # 4. Spectral features
            spectral_centroids = librosa.feature.spectral_centroid(y=y_trimmed, sr=sr)[0]
            spectral_rolloff = librosa.feature.spectral_rolloff(y=y_trimmed, sr=sr)[0]
            zero_crossing_rate = librosa.feature.zero_crossing_rate(y_trimmed)[0]
            
            features.append(float(np.mean(spectral_centroids)))   # Brightness
            features.append(float(np.std(spectral_centroids)))    # Spectral variation
            features.append(float(np.mean(spectral_rolloff)))     # High-frequency content
            features.append(float(np.mean(zero_crossing_rate)))   # Roughness indicator
            
            # 5. MFCC features (first 5 coefficients)
            mfccs = librosa.feature.mfcc(y=y_trimmed, sr=sr, n_mfcc=5)
            mfcc_mean = np.mean(mfccs, axis=1)
            
            for coeff in mfcc_mean:
                features.append(float(coeff))
            
            # 6. Additional prosodic features
            onset_frames = librosa.onset.onset_detect(y=y_trimmed, sr=sr)
            speech_rate = len(onset_frames) / (len(y_trimmed) / sr)
            features.append(float(speech_rate))
            
            # Convert to numpy array
            feature_array = np.array(features, dtype=np.float32)
            
            # Ensure consistent length (should be 18 features)
            expected_length = 18
            if len(feature_array) < expected_length:
                # Pad with zeros
                feature_array = np.pad(feature_array, (0, expected_length - len(feature_array)), mode='constant')
            elif len(feature_array) > expected_length:
                # Truncate
                feature_array = feature_array[:expected_length]
            
            return feature_array
            
        except Exception as e:
            print(f"Error extracting mood features from {audio_path}: {e}")
            # Return a default feature vector
            return np.zeros(18, dtype=np.float32)
    
    def predict_mood(self, audio_path, return_probabilities=False):
        """
        Predict mood from audio file using rule-based approach
        """
        features = self.extract_mood_features(audio_path)
        if features is None or np.all(features == 0):
            return "Error", 0.0
        
        # Use rule-based prediction since we don't have trained models
        return self._rule_based_mood_prediction(features, return_probabilities)
    
    def _rule_based_mood_prediction(self, features, return_probabilities=False):
        """
        Simple rule-based mood prediction
        """
        try:
            # Extract key features
            avg_pitch = features[0]      # Average F0
            pitch_var = features[1]      # Pitch variation
            avg_energy = features[3]     # Average energy
            energy_var = features[4]     # Energy variation
            tempo = features[7]          # Tempo
            brightness = features[8]     # Spectral centroid
            
            # Normalize features for comparison
            energy_norm = min(avg_energy * 1000, 1.0)  # Scale energy
            pitch_norm = min(avg_pitch / 200.0, 1.0)   # Scale pitch
            tempo_norm = min(tempo / 150.0, 1.0)       # Scale tempo
            
            # Rule-based classification
            mood_scores = {
                "Happy": 0.0,
                "Sad": 0.0,
                "Angry": 0.0,
                "Calm": 0.0,
                "Excited": 0.0,
                "Neutral": 0.5  # Base score for neutral
            }
            
            # Happy: High energy, higher pitch, moderate tempo
            if energy_norm > 0.3 and pitch_norm > 0.4:
                mood_scores["Happy"] += 0.4
            if tempo_norm > 0.6:
                mood_scores["Happy"] += 0.3
            if brightness > 2000:
                mood_scores["Happy"] += 0.2
            
            # Sad: Low energy, lower pitch, slow tempo
            if energy_norm < 0.2:
                mood_scores["Sad"] += 0.4
            if pitch_norm < 0.3:
                mood_scores["Sad"] += 0.3
            if tempo_norm < 0.5:
                mood_scores["Sad"] += 0.3
            
            # Angry: High energy, variable pitch, fast tempo
            if energy_norm > 0.4:
                mood_scores["Angry"] += 0.3
            if pitch_var > 20:
                mood_scores["Angry"] += 0.3
            if tempo_norm > 0.8:
                mood_scores["Angry"] += 0.3
            
            # Excited: Very high energy, high pitch, fast tempo
            if energy_norm > 0.5:
                mood_scores["Excited"] += 0.4
            if pitch_norm > 0.6:
                mood_scores["Excited"] += 0.3
            if tempo_norm > 0.7:
                mood_scores["Excited"] += 0.3
            
            # Calm: Moderate energy, stable pitch, moderate tempo
            if 0.1 < energy_norm < 0.4:
                mood_scores["Calm"] += 0.3
            if pitch_var < 15:
                mood_scores["Calm"] += 0.3
            if 0.4 < tempo_norm < 0.7:
                mood_scores["Calm"] += 0.3
            
            # Find the mood with highest score
            predicted_mood = max(mood_scores, key=mood_scores.get)
            confidence = mood_scores[predicted_mood]
            
            # Ensure minimum confidence
            if confidence < 0.3:
                predicted_mood = "Neutral"
                confidence = 0.6
            
            if return_probabilities:
                # Return sorted list of (mood, probability)
                total_score = sum(mood_scores.values())
                if total_score > 0:
                    normalized_scores = [(mood, score/total_score) for mood, score in mood_scores.items()]
                else:
                    normalized_scores = [(mood, 1.0/len(mood_scores)) for mood in mood_scores.keys()]
                return sorted(normalized_scores, key=lambda x: x[1], reverse=True)
            else:
                return predicted_mood, confidence
            
        except Exception as e:
            print(f"Error in rule-based mood prediction: {e}")
            return "Neutral", 0.5
    
    def train_model(self, training_data_folder):
        """
        Placeholder for future model training
        """
        print("Model training not implemented yet. Using rule-based prediction.")
        return True
    
    def save_model(self, filepath):
        """
        Placeholder for model saving
        """
        print("Model saving not implemented yet.")
        return True
    
    def load_model(self, filepath):
        """
        Placeholder for model loading
        """
        print("Model loading not implemented yet.")
        return True
