#!/usr/bin/env python3
"""
Quick test to verify the voice identification system works end-to-end
"""

from voice_id import VoiceIdentifier
import os

def test_voice_identification():
    print("=== Voice Identification System Test ===")
    
    # Initialize the voice identifier
    identifier = VoiceIdentifier()
    print("✓ VoiceIdentifier initialized")
    
    # Test training
    if os.path.exists("training_data"):
        print("\n--- Testing Training ---")
        success = identifier.train_model("training_data")
        if success:
            print("✓ Training completed successfully")
        else:
            print("✗ Training failed")
            return False
    else:
        print("✗ No training data found")
        return False
    
    # Test identification
    print("\n--- Testing Identification ---")
    test_files = [
        "training_data/Priya/Priya_sample_1_20250624_161529.wav",
        "training_data/Kashish/Kashish_sample_1_20250624_161949.wav"
    ]
    
    for test_file in test_files:
        if os.path.exists(test_file):
            result = identifier.identify_speaker(test_file)
            if isinstance(result, tuple):
                speaker, confidence = result
                print(f"✓ {os.path.basename(test_file)}: {speaker} ({confidence:.1%})")
            else:
                print(f"✗ {test_file}: {result}")
        else:
            print(f"✗ Test file not found: {test_file}")
    
    # Test model save/load
    print("\n--- Testing Model Save/Load ---")
    try:
        identifier.save_model("test_model.pkl")
        print("✓ Model saved")
        
        new_identifier = VoiceIdentifier()
        new_identifier.load_model("test_model.pkl")
        print("✓ Model loaded")
        
        # Test loaded model
        if os.path.exists(test_files[0]):
            result = new_identifier.identify_speaker(test_files[0])
            if isinstance(result, tuple):
                speaker, confidence = result
                print(f"✓ Loaded model test: {speaker} ({confidence:.1%})")
            else:
                print(f"✗ Loaded model test failed: {result}")
        
        # Clean up
        os.remove("test_model.pkl")
        print("✓ Test model file cleaned up")
        
    except Exception as e:
        print(f"✗ Model save/load error: {e}")
    
    print("\n=== Test Complete ===")
    return True

if __name__ == "__main__":
    test_voice_identification()
