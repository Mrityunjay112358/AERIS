import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import os
from voice_id import VoiceIdentifier
from voice_recorder import VoiceRecorder

class VoiceIdentifierGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Voice Identifier Application")
        self.root.geometry("800x600")
        self.root.configure(bg='#f0f0f0')
        
        # Initialize components
        self.identifier = VoiceIdentifier()
        self.recorder = VoiceRecorder()
        self.recording = False
        
        self.setup_ui()
        
    def setup_ui(self):
        """
        Setup the user interface
        """
        # Title
        title_label = tk.Label(self.root, text="Voice Identifier Application", 
                              font=("Arial", 20, "bold"), bg='#f0f0f0', fg='#333')
        title_label.pack(pady=20)
        
        # Main notebook for tabs
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill='both', expand=True, padx=20, pady=10)
        
        # Tab 1: Training
        self.training_frame = ttk.Frame(notebook)
        notebook.add(self.training_frame, text="Training")
        self.setup_training_tab()
        
        # Tab 2: Voice Recording
        self.recording_frame = ttk.Frame(notebook)
        notebook.add(self.recording_frame, text="Voice Recording")
        self.setup_recording_tab()
        
        # Tab 3: Identification
        self.identification_frame = ttk.Frame(notebook)
        notebook.add(self.identification_frame, text="Identification")
        self.setup_identification_tab()
        
        # Tab 4: Mood Analysis
        self.mood_frame = ttk.Frame(notebook)
        notebook.add(self.mood_frame, text="Mood Analysis")
        self.setup_mood_tab()
        
        # Tab 5: Speech-to-Text
        self.stt_frame = ttk.Frame(notebook)
        notebook.add(self.stt_frame, text="Speech-to-Text")
        self.setup_stt_tab()
        
        # Tab 6: ESP32 Communication
        self.esp32_frame = ttk.Frame(notebook)
        notebook.add(self.esp32_frame, text="ESP32 Control")
        self.setup_esp32_tab()
        
        # Status bar
        self.status_var = tk.StringVar()
        self.status_var.set("Ready")
        status_bar = tk.Label(self.root, textvariable=self.status_var, 
                             relief=tk.SUNKEN, anchor=tk.W, bg='#e0e0e0')
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)
    
    def setup_training_tab(self):
        """
        Setup the training tab
        """
        # Training data selection
        tk.Label(self.training_frame, text="Training Data Management", 
                font=("Arial", 14, "bold")).pack(pady=10)
        
        # Data folder selection
        data_frame = tk.Frame(self.training_frame)
        data_frame.pack(pady=10, padx=20, fill='x')
        
        tk.Label(data_frame, text="Training Data Folder:").pack(anchor='w')
        self.data_folder_var = tk.StringVar()
        data_folder_frame = tk.Frame(data_frame)
        data_folder_frame.pack(fill='x', pady=5)
        
        tk.Entry(data_folder_frame, textvariable=self.data_folder_var, width=50).pack(side='left', fill='x', expand=True)
        tk.Button(data_folder_frame, text="Browse", command=self.browse_data_folder).pack(side='right', padx=(5,0))
        tk.Button(data_folder_frame, text="Use Default", command=self.use_default_data_folder).pack(side='right', padx=(5,0))
        
        # Training controls
        training_controls = tk.Frame(self.training_frame)
        training_controls.pack(pady=20)
        
        tk.Button(training_controls, text="Train Model", command=self.train_model,
                 bg='#4CAF50', fg='white', font=("Arial", 12), padx=20, pady=10).pack(side='left', padx=10)
        
        tk.Button(training_controls, text="Save Model", command=self.save_model,
                 bg='#2196F3', fg='white', font=("Arial", 12), padx=20, pady=10).pack(side='left', padx=10)
        
        tk.Button(training_controls, text="Load Model", command=self.load_model,
                 bg='#FF9800', fg='white', font=("Arial", 12), padx=20, pady=10).pack(side='left', padx=10)
        
        # Training guidance
        guidance_frame = tk.Frame(self.training_frame)
        guidance_frame.pack(pady=10, padx=20, fill='x')
        
        guidance_text = tk.Text(guidance_frame, height=4, wrap=tk.WORD, bg='#f8f9fa', 
                               font=("Arial", 10), relief=tk.FLAT, borderwidth=0)
        guidance_text.pack(fill='x')
        guidance_text.insert(tk.END, 
            "💡 Training Tips:\n"
            "• You need at least 2 different speakers for training\n"
            "• Each speaker should have 3-5 voice samples\n"
            "• Use the 'Voice Recording' tab to collect samples first"
        )
        guidance_text.config(state=tk.DISABLED)
        
        # Training log
        tk.Label(self.training_frame, text="Training Log:", font=("Arial", 12)).pack(anchor='w', padx=20, pady=(20,5))
        
        log_frame = tk.Frame(self.training_frame)
        log_frame.pack(padx=20, pady=5, fill='both', expand=True)
        
        self.training_log = tk.Text(log_frame, height=10, wrap=tk.WORD)
        scrollbar = tk.Scrollbar(log_frame, orient="vertical", command=self.training_log.yview)
        self.training_log.configure(yscrollcommand=scrollbar.set)
        
        self.training_log.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
    
    def setup_recording_tab(self):
        """
        Setup the voice recording tab
        """
        tk.Label(self.recording_frame, text="Voice Sample Collection", 
                font=("Arial", 14, "bold")).pack(pady=10)
        
        # Speaker name input
        speaker_frame = tk.Frame(self.recording_frame)
        speaker_frame.pack(pady=10, padx=20, fill='x')
        
        tk.Label(speaker_frame, text="Speaker Name:").pack(anchor='w')
        self.speaker_name_var = tk.StringVar()
        tk.Entry(speaker_frame, textvariable=self.speaker_name_var, font=("Arial", 12)).pack(fill='x', pady=5)
        
        # Recording settings
        settings_frame = tk.Frame(self.recording_frame)
        settings_frame.pack(pady=10, padx=20, fill='x')
        
        tk.Label(settings_frame, text="Recording Duration (seconds):").pack(anchor='w')
        self.duration_var = tk.StringVar(value="5")
        tk.Entry(settings_frame, textvariable=self.duration_var, width=10).pack(anchor='w', pady=5)
        
        # Recording controls
        record_controls = tk.Frame(self.recording_frame)
        record_controls.pack(pady=20)
        
        self.record_button = tk.Button(record_controls, text="Start Recording", 
                                      command=self.toggle_recording,
                                      bg='#F44336', fg='white', font=("Arial", 12), 
                                      padx=20, pady=10)
        self.record_button.pack(pady=10)
        
        tk.Button(record_controls, text="Collect Voice Samples", 
                 command=self.collect_samples,
                 bg='#9C27B0', fg='white', font=("Arial", 12), 
                 padx=20, pady=10).pack(pady=10)
        
        # Recording status
        self.recording_status_var = tk.StringVar()
        self.recording_status_var.set("Not recording")
        tk.Label(self.recording_frame, textvariable=self.recording_status_var, 
                font=("Arial", 12)).pack(pady=10)
    
    def setup_identification_tab(self):
        """
        Setup the identification tab
        """
        tk.Label(self.identification_frame, text="Voice Identification", 
                font=("Arial", 14, "bold")).pack(pady=10)
        
        # Audio file selection
        file_frame = tk.Frame(self.identification_frame)
        file_frame.pack(pady=10, padx=20, fill='x')
        
        tk.Label(file_frame, text="Audio File:").pack(anchor='w')
        self.audio_file_var = tk.StringVar()
        audio_file_frame = tk.Frame(file_frame)
        audio_file_frame.pack(fill='x', pady=5)
        
        tk.Entry(audio_file_frame, textvariable=self.audio_file_var, width=50).pack(side='left', fill='x', expand=True)
        tk.Button(audio_file_frame, text="Browse", command=self.browse_audio_file).pack(side='right', padx=(5,0))
        
        # Identification controls
        id_controls = tk.Frame(self.identification_frame)
        id_controls.pack(pady=20)
        
        tk.Button(id_controls, text="Identify Speaker", command=self.identify_speaker,
                 bg='#607D8B', fg='white', font=("Arial", 12), padx=20, pady=10).pack(pady=10)
        
        # Results display
        tk.Label(self.identification_frame, text="Results:", font=("Arial", 12)).pack(anchor='w', padx=20, pady=(20,5))
        
        results_frame = tk.Frame(self.identification_frame)
        results_frame.pack(padx=20, pady=5, fill='both', expand=True)
        
        self.results_text = tk.Text(results_frame, height=10, wrap=tk.WORD)
        results_scrollbar = tk.Scrollbar(results_frame, orient="vertical", command=self.results_text.yview)
        self.results_text.configure(yscrollcommand=results_scrollbar.set)
        
        self.results_text.pack(side="left", fill="both", expand=True)
        results_scrollbar.pack(side="right", fill="y")
    
    def setup_mood_tab(self):
        """
        Setup the mood analysis tab
        """
        tk.Label(self.mood_frame, text="Voice Mood Analysis", 
                font=("Arial", 14, "bold")).pack(pady=10)
        
        # Audio file selection for mood analysis
        mood_file_frame = tk.Frame(self.mood_frame)
        mood_file_frame.pack(pady=10, padx=20, fill='x')
        
        tk.Label(mood_file_frame, text="Audio File:").pack(anchor='w')
        self.mood_audio_file_var = tk.StringVar()
        mood_audio_frame = tk.Frame(mood_file_frame)
        mood_audio_frame.pack(fill='x', pady=5)
        
        tk.Entry(mood_audio_frame, textvariable=self.mood_audio_file_var, width=50).pack(side='left', fill='x', expand=True)
        tk.Button(mood_audio_frame, text="Browse", command=self.browse_mood_audio_file).pack(side='right', padx=(5,0))
        
        # Analysis controls
        mood_controls = tk.Frame(self.mood_frame)
        mood_controls.pack(pady=20)
        
        tk.Button(mood_controls, text="Analyze Mood Only", command=self.analyze_mood_only,
                 bg='#E91E63', fg='white', font=("Arial", 12), padx=20, pady=10).pack(side='left', padx=10)
        
        tk.Button(mood_controls, text="Complete Analysis\n(Speaker + Mood)", command=self.analyze_complete,
                 bg='#673AB7', fg='white', font=("Arial", 12), padx=20, pady=10).pack(side='left', padx=10)
        
        # Mood info panel
        info_frame = tk.Frame(self.mood_frame)
        info_frame.pack(pady=10, padx=20, fill='x')
        
        info_text = tk.Text(info_frame, height=3, wrap=tk.WORD, bg='#f8f9fa', 
                           font=("Arial", 10), relief=tk.FLAT, borderwidth=0)
        info_text.pack(fill='x')
        info_text.insert(tk.END, 
            "🎭 Mood Analysis:\n"
            "• Analyzes emotional state from voice characteristics\n"
            "• Detects: Happy, Sad, Angry, Calm, Excited, Neutral moods"
        )
        info_text.config(state=tk.DISABLED)
        
        # Mood results display
        tk.Label(self.mood_frame, text="Analysis Results:", font=("Arial", 12)).pack(anchor='w', padx=20, pady=(20,5))
        
        mood_results_frame = tk.Frame(self.mood_frame)
        mood_results_frame.pack(padx=20, pady=5, fill='both', expand=True)
        
        self.mood_results_text = tk.Text(mood_results_frame, height=15, wrap=tk.WORD)
        mood_scrollbar = tk.Scrollbar(mood_results_frame, orient="vertical", command=self.mood_results_text.yview)
        self.mood_results_text.configure(yscrollcommand=mood_scrollbar.set)
        
        self.mood_results_text.pack(side="left", fill="both", expand=True)
        mood_scrollbar.pack(side="right", fill="y")
    
    def browse_data_folder(self):
        """
        Browse for training data folder
        """
        folder = filedialog.askdirectory(title="Select Training Data Folder")
        if folder:
            self.data_folder_var.set(folder)
    
    def browse_audio_file(self):
        """
        Browse for audio file
        """
        file = filedialog.askopenfilename(
            title="Select Audio File",
            filetypes=[("Audio files", "*.wav *.mp3 *.flac *.m4a"), ("All files", "*.*")]
        )
        if file:
            self.audio_file_var.set(file)
    
    def browse_mood_audio_file(self):
        """
        Browse for audio file for mood analysis
        """
        file = filedialog.askopenfilename(
            title="Select Audio File for Mood Analysis",
            filetypes=[("Audio files", "*.wav *.mp3 *.flac *.m4a"), ("All files", "*.*")]
        )
        if file:
            self.mood_audio_file_var.set(file)
    
    def train_model(self):
        """
        Train the voice identification model
        """
        data_folder = self.data_folder_var.get()
        if not data_folder or not os.path.exists(data_folder):
            messagebox.showerror("Error", "Please select a valid training data folder")
            return
        
        def train_thread():
            self.status_var.set("Training model...")
            self.training_log.insert(tk.END, f"Starting training with data from: {data_folder}\n")
            self.training_log.see(tk.END)
            
            try:
                # Check if training data has multiple speakers first
                speaker_count = 0
                for item in os.listdir(data_folder):
                    if os.path.isdir(os.path.join(data_folder, item)):
                        speaker_count += 1
                
                if speaker_count < 2:
                    self.training_log.insert(tk.END, f"Error: Found only {speaker_count} speaker(s) in training data.\n")
                    self.training_log.insert(tk.END, "You need at least 2 different speakers for training.\n")
                    self.training_log.insert(tk.END, "Please use the 'Voice Recording' tab to collect samples for more speakers.\n")
                    self.status_var.set("Training failed - Need more speakers")
                    messagebox.showerror("Training Error", 
                        f"Need at least 2 speakers for training.\n\n"
                        f"Found: {speaker_count} speaker(s)\n"
                        f"Required: 2 or more speakers\n\n"
                        f"Use the 'Voice Recording' tab to collect samples for additional speakers.")
                    return
                
                success = self.identifier.train_model(data_folder)
                if success:
                    self.training_log.insert(tk.END, "Training completed successfully!\n")
                    self.status_var.set("Training completed")
                    messagebox.showinfo("Success", "Model trained successfully!")
                else:
                    self.training_log.insert(tk.END, "Training failed!\n")
                    self.status_var.set("Training failed")
                    messagebox.showerror("Error", "Training failed. Check the training log for details.")
            except Exception as e:
                self.training_log.insert(tk.END, f"Error during training: {e}\n")
                self.status_var.set("Training error")
                messagebox.showerror("Error", f"Training error: {e}")
            
            self.training_log.see(tk.END)
        
        threading.Thread(target=train_thread, daemon=True).start()
    
    def save_model(self):
        """
        Save the trained model
        """
        if self.identifier.model is None:
            messagebox.showerror("Error", "No model to save. Please train a model first.")
            return
        
        # Create models directory if it doesn't exist
        models_dir = os.path.join(os.getcwd(), "models")
        os.makedirs(models_dir, exist_ok=True)
        
        file = filedialog.asksaveasfilename(
            initialdir=models_dir,
            defaultextension=".pkl",
            filetypes=[("Pickle files", "*.pkl"), ("All files", "*.*")]
        )
        if file:
            try:
                self.identifier.save_model(file)
                messagebox.showinfo("Success", "Model saved successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Error saving model: {e}")
    
    def load_model(self):
        """
        Load a pre-trained model
        """
        # Create models directory if it doesn't exist
        models_dir = os.path.join(os.getcwd(), "models")
        os.makedirs(models_dir, exist_ok=True)
        
        file = filedialog.askopenfilename(
            initialdir=models_dir,
            filetypes=[("Pickle files", "*.pkl"), ("All files", "*.*")]
        )
        if file:
            try:
                self.identifier.load_model(file)
                self.training_log.insert(tk.END, f"Model loaded from: {file}\n")
                self.training_log.insert(tk.END, f"Speakers: {list(self.identifier.speakers.values())}\n")
                self.training_log.see(tk.END)
                messagebox.showinfo("Success", "Model loaded successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Error loading model: {e}")
    
    def toggle_recording(self):
        """
        Start or stop recording
        """
        if not self.recording:
            self.recording = True
            self.recorder.start_recording()
            self.record_button.config(text="Stop Recording", bg='#4CAF50')
            self.recording_status_var.set("Recording...")
        else:
            self.recording = False
            from datetime import datetime
            filename = f"recording_{datetime.now().strftime('%Y%m%d_%H%M%S')}.wav"
            self.recorder.stop_recording(filename)
            self.record_button.config(text="Start Recording", bg='#F44336')
            self.recording_status_var.set(f"Recording saved: {filename}")
    
    def collect_samples(self):
        """
        Collect voice samples for a speaker
        """
        speaker_name = self.speaker_name_var.get().strip()
        if not speaker_name:
            messagebox.showerror("Error", "Please enter a speaker name")
            return
        
        try:
            duration = int(self.duration_var.get())
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid duration")
            return
        
        def collect_thread():
            try:
                # Create training_data directory if it doesn't exist
                os.makedirs("training_data", exist_ok=True)
                
                self.status_var.set(f"Collecting samples for {speaker_name}")
                
                # Collect 5 samples by default
                num_samples = 5
                for i in range(num_samples):
                    response = messagebox.askokcancel(
                        "Voice Sample Collection",
                        f"Ready to record sample {i+1}/{num_samples} for {speaker_name}?\n"
                        f"Duration: {duration} seconds\n\n"
                        f"Click OK to start recording, Cancel to skip."
                    )
                    
                    if response:
                        speaker_dir = os.path.join("training_data", speaker_name)
                        os.makedirs(speaker_dir, exist_ok=True)
                        
                        from datetime import datetime
                        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                        filename = os.path.join(speaker_dir, f"{speaker_name}_sample_{i+1}_{timestamp}.wav")
                        
                        self.recorder.record_audio(duration, filename)
                        self.recording_status_var.set(f"Sample {i+1} saved: {filename}")
                    else:
                        break
                
                self.status_var.set("Sample collection completed")
                messagebox.showinfo("Success", f"Voice samples collected for {speaker_name}")
                
            except Exception as e:
                messagebox.showerror("Error", f"Error collecting samples: {e}")
        
        threading.Thread(target=collect_thread, daemon=True).start()
    
    def identify_speaker(self):
        """
        Identify speaker from audio file
        """
        audio_file = self.audio_file_var.get()
        if not audio_file or not os.path.exists(audio_file):
            messagebox.showerror("Error", "Please select a valid audio file")
            return
        
        if self.identifier.model is None:
            messagebox.showerror("Error", "No model loaded. Please train or load a model first.")
            return
        
        def identify_thread():
            try:
                self.status_var.set("Identifying speaker...")
                self.results_text.delete(1.0, tk.END)
                
                # Get detailed results with probabilities
                results = self.identifier.identify_speaker(audio_file, return_probabilities=True)
                
                if isinstance(results, str):
                    self.results_text.insert(tk.END, f"Error: {results}\n")
                else:
                    self.results_text.insert(tk.END, f"Voice Identification Results for: {os.path.basename(audio_file)}\n")
                    self.results_text.insert(tk.END, "="*50 + "\n\n")
                    
                    for i, (speaker, probability) in enumerate(results):
                        if i == 0:
                            self.results_text.insert(tk.END, f"🏆 MOST LIKELY: {speaker} ({probability:.2%})\n\n")
                        else:
                            self.results_text.insert(tk.END, f"{i+1}. {speaker}: {probability:.2%}\n")
                    
                    # Also get simple result
                    speaker, confidence = self.identifier.identify_speaker(audio_file)
                    self.results_text.insert(tk.END, f"\nPredicted Speaker: {speaker}\n")
                    self.results_text.insert(tk.END, f"Confidence: {confidence:.2%}\n")
                
                self.status_var.set("Identification completed")
                
            except Exception as e:
                self.results_text.insert(tk.END, f"Error during identification: {e}\n")
                self.status_var.set("Identification error")
        
        threading.Thread(target=identify_thread, daemon=True).start()

    def analyze_mood_only(self):
        """
        Analyze only the mood from audio file
        """
        audio_file = self.mood_audio_file_var.get()
        if not audio_file or not os.path.exists(audio_file):
            messagebox.showerror("Error", "Please select a valid audio file")
            return
        
        def mood_thread():
            try:
                self.status_var.set("Analyzing mood...")
                self.mood_results_text.delete(1.0, tk.END)
                
                # Get mood analysis
                mood_result = self.identifier.mood_analyzer.predict_mood(audio_file, return_probabilities=True)
                
                if isinstance(mood_result, str):
                    self.mood_results_text.insert(tk.END, f"Error: {mood_result}\n")
                else:
                    self.mood_results_text.insert(tk.END, f"🎭 Mood Analysis Results for: {os.path.basename(audio_file)}\n")
                    self.mood_results_text.insert(tk.END, "="*60 + "\n\n")
                    
                    if isinstance(mood_result, tuple):
                        # Simple result
                        mood, confidence = mood_result
                        self.mood_results_text.insert(tk.END, f"🎯 DETECTED MOOD: {mood}\n")
                        self.mood_results_text.insert(tk.END, f"📊 Confidence: {confidence:.2%}\n\n")
                        
                        # Add mood description
                        mood_descriptions = {
                            "Happy": "😊 Positive, upbeat emotional state",
                            "Sad": "😢 Low energy, melancholic emotional state", 
                            "Angry": "😠 High arousal, negative emotional state",
                            "Calm": "😌 Relaxed, peaceful emotional state",
                            "Excited": "🤩 High energy, enthusiastic emotional state",
                            "Neutral": "😐 Balanced, emotionally neutral state"
                        }
                        
                        description = mood_descriptions.get(mood, "Emotional state detected")
                        self.mood_results_text.insert(tk.END, f"Description: {description}\n")
                    else:
                        # Detailed probabilities
                        for i, (mood, probability) in enumerate(mood_result):
                            if i == 0:
                                self.mood_results_text.insert(tk.END, f"🎯 PRIMARY MOOD: {mood} ({probability:.2%})\n\n")
                            else:
                                self.mood_results_text.insert(tk.END, f"   {i+1}. {mood}: {probability:.2%}\n")
                
                self.status_var.set("Mood analysis completed")
                
            except Exception as e:
                self.mood_results_text.insert(tk.END, f"Error during mood analysis: {e}\n")
                self.status_var.set("Mood analysis error")
        
        threading.Thread(target=mood_thread, daemon=True).start()
    
    def analyze_complete(self):
        """
        Perform complete analysis (speaker + mood)
        """
        audio_file = self.mood_audio_file_var.get()
        if not audio_file or not os.path.exists(audio_file):
            messagebox.showerror("Error", "Please select a valid audio file")
            return
        
        if self.identifier.model is None:
            messagebox.showerror("Error", "No speaker model loaded. Please train or load a model first.")
            return
        
        def complete_thread():
            try:
                self.status_var.set("Performing complete analysis...")
                self.mood_results_text.delete(1.0, tk.END)
                
                # Get complete analysis
                results = self.identifier.analyze_audio_complete(audio_file)
                
                if isinstance(results, str):
                    self.mood_results_text.insert(tk.END, f"Error: {results}\n")
                else:
                    self.mood_results_text.insert(tk.END, f"🎙️ COMPLETE VOICE ANALYSIS\n")
                    self.mood_results_text.insert(tk.END, f"File: {os.path.basename(audio_file)}\n")
                    self.mood_results_text.insert(tk.END, "="*60 + "\n\n")
                    
                    # Speaker results
                    speaker_data = results['speaker']
                    self.mood_results_text.insert(tk.END, f"👤 SPEAKER IDENTIFICATION:\n")
                    self.mood_results_text.insert(tk.END, f"   🏆 Identified: {speaker_data['prediction']}\n")
                    self.mood_results_text.insert(tk.END, f"   📊 Confidence: {speaker_data['confidence']:.2%}\n\n")
                    
                    # Mood results
                    mood_data = results['mood']
                    self.mood_results_text.insert(tk.END, f"🎭 MOOD ANALYSIS:\n")
                    self.mood_results_text.insert(tk.END, f"   🎯 Detected: {mood_data['prediction']}\n")
                    self.mood_results_text.insert(tk.END, f"   📊 Confidence: {mood_data['confidence']:.2%}\n\n")
                    
                    # Detailed probabilities if available
                    if speaker_data.get('probabilities'):
                        self.mood_results_text.insert(tk.END, f"👥 SPEAKER PROBABILITIES:\n")
                        for i, (speaker, prob) in enumerate(speaker_data['probabilities'][:3]):
                            self.mood_results_text.insert(tk.END, f"   {i+1}. {speaker}: {prob:.2%}\n")
                        self.mood_results_text.insert(tk.END, "\n")
                    
                    if mood_data.get('probabilities') and isinstance(mood_data['probabilities'], list):
                        self.mood_results_text.insert(tk.END, f"🎭 MOOD PROBABILITIES:\n")
                        for i, (mood, prob) in enumerate(mood_data['probabilities'][:3]):
                            self.mood_results_text.insert(tk.END, f"   {i+1}. {mood}: {prob:.2%}\n")
                    
                    # Summary
                    self.mood_results_text.insert(tk.END, f"\n" + "="*60 + "\n")
                    self.mood_results_text.insert(tk.END, f"📋 SUMMARY:\n")
                    self.mood_results_text.insert(tk.END, f"   • Speaker: {speaker_data['prediction']} ({speaker_data['confidence']:.1%})\n")
                    self.mood_results_text.insert(tk.END, f"   • Mood: {mood_data['prediction']} ({mood_data['confidence']:.1%})\n")
                
                self.status_var.set("Complete analysis finished")
                
            except Exception as e:
                self.mood_results_text.insert(tk.END, f"Error during complete analysis: {e}\n")
                self.status_var.set("Analysis error")
        
        threading.Thread(target=complete_thread, daemon=True).start()

    def use_default_data_folder(self):
        """
        Set the default training data folder
        """
        default_folder = os.path.join(os.getcwd(), "training_data")
        self.data_folder_var.set(default_folder)
        if not os.path.exists(default_folder):
            os.makedirs(default_folder, exist_ok=True)
            self.training_log.insert(tk.END, f"Created training data folder: {default_folder}\n")
            self.training_log.see(tk.END)
    
    def setup_stt_tab(self):
        """
        Setup the Speech-to-Text tab
        """
        # Title
        tk.Label(self.stt_frame, text="Speech-to-Text Conversion", 
                font=("Arial", 14, "bold")).pack(pady=10)
        
        # Configuration frame
        config_frame = tk.LabelFrame(self.stt_frame, text="Configuration", font=("Arial", 12))
        config_frame.pack(padx=20, pady=10, fill='x')
        
        # Engine selection
        engine_frame = tk.Frame(config_frame)
        engine_frame.pack(fill='x', padx=10, pady=5)
        
        tk.Label(engine_frame, text="Engine:").pack(side='left')
        self.stt_engine_var = tk.StringVar(value='google')
        engine_combo = ttk.Combobox(engine_frame, textvariable=self.stt_engine_var, 
                                   values=['google', 'sphinx', 'wit'], state='readonly', width=15)
        engine_combo.pack(side='left', padx=(10,0))
        
        # Language selection
        language_frame = tk.Frame(config_frame)
        language_frame.pack(fill='x', padx=10, pady=5)
        
        tk.Label(language_frame, text="Language:").pack(side='left')
        self.stt_language_var = tk.StringVar(value='en-US')
        language_combo = ttk.Combobox(language_frame, textvariable=self.stt_language_var,
                                     values=['en-US', 'en-GB', 'es-ES', 'fr-FR', 'de-DE', 'it-IT', 'pt-BR'], 
                                     state='readonly', width=15)
        language_combo.pack(side='left', padx=(10,0))
        
        # Apply settings button
        tk.Button(config_frame, text="Apply Settings", command=self.apply_stt_settings,
                 bg='#2196F3', fg='white', font=("Arial", 10)).pack(pady=10)
        
        # File transcription frame
        file_frame = tk.LabelFrame(self.stt_frame, text="File Transcription", font=("Arial", 12))
        file_frame.pack(padx=20, pady=10, fill='x')
        
        # Audio file selection
        self.stt_audio_file_var = tk.StringVar()
        audio_frame = tk.Frame(file_frame)
        audio_frame.pack(fill='x', padx=10, pady=5)
        
        tk.Label(audio_frame, text="Audio File:").pack(anchor='w')
        file_entry_frame = tk.Frame(audio_frame)
        file_entry_frame.pack(fill='x', pady=5)
        
        tk.Entry(file_entry_frame, textvariable=self.stt_audio_file_var, width=50).pack(side='left', fill='x', expand=True)
        tk.Button(file_entry_frame, text="Browse", command=self.browse_stt_audio_file).pack(side='right', padx=(5,0))
        
        # Transcription buttons
        button_frame = tk.Frame(file_frame)
        button_frame.pack(pady=10)
        
        tk.Button(button_frame, text="Transcribe File", command=self.transcribe_file,
                 bg='#4CAF50', fg='white', font=("Arial", 11), padx=20).pack(side='left', padx=5)
        
        tk.Button(button_frame, text="Complete Analysis", command=self.complete_analysis_with_stt,
                 bg='#FF5722', fg='white', font=("Arial", 11), padx=20).pack(side='left', padx=5)
        
        # Live recording frame
        live_frame = tk.LabelFrame(self.stt_frame, text="Live Recording & Transcription", font=("Arial", 12))
        live_frame.pack(padx=20, pady=10, fill='x')
        
        # Duration setting
        duration_frame = tk.Frame(live_frame)
        duration_frame.pack(padx=10, pady=5)
        
        tk.Label(duration_frame, text="Recording Duration:").pack(side='left')
        self.stt_duration_var = tk.IntVar(value=5)
        duration_spin = tk.Spinbox(duration_frame, from_=1, to=30, textvariable=self.stt_duration_var, width=10)
        duration_spin.pack(side='left', padx=(10,5))
        tk.Label(duration_frame, text="seconds").pack(side='left')
        
        # Live recording buttons
        live_button_frame = tk.Frame(live_frame)
        live_button_frame.pack(pady=10)
        
        tk.Button(live_button_frame, text="Record & Transcribe", command=self.record_and_transcribe,
                 bg='#9C27B0', fg='white', font=("Arial", 11), padx=20).pack(side='left', padx=5)
        
        tk.Button(live_button_frame, text="Live Complete Analysis", command=self.live_complete_analysis,
                 bg='#E91E63', fg='white', font=("Arial", 11), padx=20).pack(side='left', padx=5)
        
        # Results display
        tk.Label(self.stt_frame, text="Transcription Results:", font=("Arial", 12)).pack(anchor='w', padx=20, pady=(20,5))
        
        results_frame = tk.Frame(self.stt_frame)
        results_frame.pack(padx=20, pady=5, fill='both', expand=True)
        
        self.stt_results_text = tk.Text(results_frame, height=15, wrap=tk.WORD)
        stt_scrollbar = tk.Scrollbar(results_frame, orient="vertical", command=self.stt_results_text.yview)
        self.stt_results_text.configure(yscrollcommand=stt_scrollbar.set)
        
        self.stt_results_text.pack(side="left", fill="both", expand=True)
        stt_scrollbar.pack(side="right", fill="y")
    
    def setup_esp32_tab(self):
        """
        Setup the ESP32 Communication tab
        """
        # Title
        tk.Label(self.esp32_frame, text="ESP32 Communication Control", 
                font=("Arial", 14, "bold")).pack(pady=10)
        
        # Connection frame
        conn_frame = tk.LabelFrame(self.esp32_frame, text="Connection Settings", font=("Arial", 12))
        conn_frame.pack(padx=20, pady=10, fill='x')
        
        # IP and port settings
        ip_frame = tk.Frame(conn_frame)
        ip_frame.pack(fill='x', padx=10, pady=5)
        
        tk.Label(ip_frame, text="ESP32 IP Address:").pack(side='left')
        self.esp32_ip_var = tk.StringVar(value='192.168.1.100')
        tk.Entry(ip_frame, textvariable=self.esp32_ip_var, width=20).pack(side='left', padx=(10,0))
        
        tk.Label(ip_frame, text="Port:").pack(side='left', padx=(20,0))
        self.esp32_port_var = tk.IntVar(value=8080)
        tk.Entry(ip_frame, textvariable=self.esp32_port_var, width=10).pack(side='left', padx=(10,0))
        
        # Connection buttons
        conn_button_frame = tk.Frame(conn_frame)
        conn_button_frame.pack(pady=10)
        
        tk.Button(conn_button_frame, text="Test Connection", command=self.test_esp32_connection,
                 bg='#2196F3', fg='white', font=("Arial", 10)).pack(side='left', padx=5)
        
        tk.Button(conn_button_frame, text="Enable TCP", command=self.enable_esp32_communication,
                 bg='#4CAF50', fg='white', font=("Arial", 10)).pack(side='left', padx=5)
        
        tk.Button(conn_button_frame, text="Disable TCP", command=self.disable_esp32_communication,
                 bg='#F44336', fg='white', font=("Arial", 10)).pack(side='left', padx=5)
        
        # Manual control frame
        manual_frame = tk.LabelFrame(self.esp32_frame, text="Manual Control", font=("Arial", 12))
        manual_frame.pack(padx=20, pady=10, fill='x')
        
        # Person and emotion code inputs
        code_frame = tk.Frame(manual_frame)
        code_frame.pack(padx=10, pady=5)
        
        tk.Label(code_frame, text="Person Code (0-3):").pack(side='left')
        self.person_code_var = tk.IntVar(value=1)
        tk.Spinbox(code_frame, from_=0, to=3, textvariable=self.person_code_var, width=5).pack(side='left', padx=(10,20))
        
        tk.Label(code_frame, text="Emotion Code (0-5):").pack(side='left')
        self.emotion_code_var = tk.IntVar(value=1)
        tk.Spinbox(code_frame, from_=0, to=5, textvariable=self.emotion_code_var, width=5).pack(side='left', padx=(10,0))
        
        tk.Button(manual_frame, text="Send Codes", command=self.send_manual_codes,
                 bg='#FF9800', fg='white', font=("Arial", 10)).pack(pady=10)
        
        # Status display
        tk.Label(self.esp32_frame, text="ESP32 Status:", font=("Arial", 12)).pack(anchor='w', padx=20, pady=(20,5))
        
        esp32_status_frame = tk.Frame(self.esp32_frame)
        esp32_status_frame.pack(padx=20, pady=5, fill='both', expand=True)
        
        self.esp32_status_text = tk.Text(esp32_status_frame, height=10, wrap=tk.WORD)
        esp32_status_scrollbar = tk.Scrollbar(esp32_status_frame, orient="vertical", command=self.esp32_status_text.yview)
        self.esp32_status_text.configure(yscrollcommand=esp32_status_scrollbar.set)
        
        self.esp32_status_text.pack(side="left", fill="both", expand=True)
        esp32_status_scrollbar.pack(side="right", fill="y")
    
    # Speech-to-Text Methods
    def apply_stt_settings(self):
        """Apply speech-to-text settings"""
        engine = self.stt_engine_var.get()
        language = self.stt_language_var.get()
        
        self.identifier.enable_speech_to_text(engine, language)
        
        self.stt_results_text.insert(tk.END, f"✅ Settings applied: Engine={engine}, Language={language}\n")
        self.stt_results_text.see(tk.END)
        
        messagebox.showinfo("Success", f"Speech-to-text configured: {engine} ({language})")
    
    def browse_stt_audio_file(self):
        """Browse for audio file for transcription"""
        file = filedialog.askopenfilename(
            title="Select Audio File for Transcription",
            filetypes=[("Audio files", "*.wav *.mp3 *.flac *.m4a"), ("All files", "*.*")]
        )
        if file:
            self.stt_audio_file_var.set(file)
    
    def transcribe_file(self):
        """Transcribe selected audio file"""
        audio_file = self.stt_audio_file_var.get()
        if not audio_file or not os.path.exists(audio_file):
            messagebox.showerror("Error", "Please select a valid audio file")
            return
        
        def transcribe_thread():
            try:
                self.status_var.set("Transcribing audio...")
                self.stt_results_text.insert(tk.END, f"🔄 Transcribing: {os.path.basename(audio_file)}\n")
                self.stt_results_text.insert(tk.END, "="*50 + "\n")
                
                result = self.identifier.transcribe_audio_file(audio_file)
                
                if result['success']:
                    self.stt_results_text.insert(tk.END, f"✅ TRANSCRIPTION SUCCESSFUL\n")
                    self.stt_results_text.insert(tk.END, f"📝 Text: \"{result['transcription']}\"\n")
                    self.stt_results_text.insert(tk.END, f"📊 Confidence: {result['confidence']:.1%}\n")
                    self.stt_results_text.insert(tk.END, f"🔧 Engine: {result['engine']}\n")
                    self.stt_results_text.insert(tk.END, f"🌐 Language: {result['language']}\n")
                else:
                    self.stt_results_text.insert(tk.END, f"❌ TRANSCRIPTION FAILED\n")
                    self.stt_results_text.insert(tk.END, f"Error: {result['error']}\n")
                
                self.stt_results_text.insert(tk.END, "\n")
                self.stt_results_text.see(tk.END)
                self.status_var.set("Transcription completed")
                
            except Exception as e:
                self.stt_results_text.insert(tk.END, f"❌ Error: {e}\n\n")
                self.status_var.set("Transcription error")
        
        threading.Thread(target=transcribe_thread, daemon=True).start()
    
    def record_and_transcribe(self):
        """Record audio and transcribe"""
        duration = self.stt_duration_var.get()
        
        def record_thread():
            try:
                self.status_var.set(f"Recording for {duration} seconds...")
                self.stt_results_text.insert(tk.END, f"🎤 Recording for {duration} seconds...\n")
                self.stt_results_text.see(tk.END)
                
                result = self.identifier.transcribe_microphone(duration)
                
                if result['success']:
                    self.stt_results_text.insert(tk.END, f"✅ LIVE TRANSCRIPTION SUCCESSFUL\n")
                    self.stt_results_text.insert(tk.END, f"📝 Text: \"{result['transcription']}\"\n")
                    self.stt_results_text.insert(tk.END, f"📊 Confidence: {result['confidence']:.1%}\n")
                else:
                    self.stt_results_text.insert(tk.END, f"❌ LIVE TRANSCRIPTION FAILED\n")
                    self.stt_results_text.insert(tk.END, f"Error: {result['error']}\n")
                
                self.stt_results_text.insert(tk.END, "\n")
                self.stt_results_text.see(tk.END)
                self.status_var.set("Live transcription completed")
                
            except Exception as e:
                self.stt_results_text.insert(tk.END, f"❌ Error: {e}\n\n")
                self.status_var.set("Live transcription error")
        
        threading.Thread(target=record_thread, daemon=True).start()
    
    def complete_analysis_with_stt(self):
        """Perform complete analysis including speech-to-text"""
        audio_file = self.stt_audio_file_var.get()
        if not audio_file or not os.path.exists(audio_file):
            messagebox.showerror("Error", "Please select a valid audio file")
            return
        
        def analysis_thread():
            try:
                self.status_var.set("Performing complete analysis...")
                self.stt_results_text.insert(tk.END, f"🔄 Complete Analysis: {os.path.basename(audio_file)}\n")
                self.stt_results_text.insert(tk.END, "="*60 + "\n")
                
                results = self.identifier.analyze_with_transcription(audio_file)
                
                # Display transcription results
                if results['transcription']:
                    trans = results['transcription']
                    self.stt_results_text.insert(tk.END, f"📝 SPEECH-TO-TEXT:\n")
                    if trans['success']:
                        self.stt_results_text.insert(tk.END, f"   Text: \"{trans['transcription']}\"\n")
                        self.stt_results_text.insert(tk.END, f"   Confidence: {trans['confidence']:.1%}\n")
                    else:
                        self.stt_results_text.insert(tk.END, f"   Error: {trans['error']}\n")
                    self.stt_results_text.insert(tk.END, "\n")
                
                # Display speaker results
                if results['speaker']:
                    speaker = results['speaker']
                    self.stt_results_text.insert(tk.END, f"👤 SPEAKER IDENTIFICATION:\n")
                    self.stt_results_text.insert(tk.END, f"   Identified: {speaker['prediction']}\n")
                    self.stt_results_text.insert(tk.END, f"   Confidence: {speaker['confidence']:.1%}\n\n")
                
                # Display emotion results
                if results['mood']:
                    mood = results['mood']
                    self.stt_results_text.insert(tk.END, f"😊 EMOTION ANALYSIS:\n")
                    self.stt_results_text.insert(tk.END, f"   Detected: {mood['prediction']}\n")
                    self.stt_results_text.insert(tk.END, f"   Confidence: {mood['confidence']:.1%}\n\n")
                
                # ESP32 status
                if results['esp32_sent']:
                    self.stt_results_text.insert(tk.END, f"📡 ESP32: ✅ Data sent successfully\n")
                else:
                    self.stt_results_text.insert(tk.END, f"📡 ESP32: ❌ Not sent or failed\n")
                
                self.stt_results_text.insert(tk.END, "\n")
                self.stt_results_text.see(tk.END)
                self.status_var.set("Complete analysis finished")
                
            except Exception as e:
                self.stt_results_text.insert(tk.END, f"❌ Error: {e}\n\n")
                self.status_var.set("Analysis error")
        
        threading.Thread(target=analysis_thread, daemon=True).start()
    
    def live_complete_analysis(self):
        """Perform live complete analysis"""
        duration = self.stt_duration_var.get()
        
        def live_analysis_thread():
            try:
                self.status_var.set(f"Live recording and analysis ({duration}s)...")
                self.stt_results_text.insert(tk.END, f"🎤 LIVE COMPLETE ANALYSIS ({duration}s)\n")
                self.stt_results_text.insert(tk.END, "="*60 + "\n")
                
                results = self.identifier.record_and_analyze_live(duration, include_transcription=True)
                
                # Display all results similar to complete_analysis_with_stt
                if results['transcription']:
                    trans = results['transcription']
                    self.stt_results_text.insert(tk.END, f"📝 SPEECH-TO-TEXT:\n")
                    if trans['success']:
                        self.stt_results_text.insert(tk.END, f"   Text: \"{trans['transcription']}\"\n")
                        self.stt_results_text.insert(tk.END, f"   Confidence: {trans['confidence']:.1%}\n")
                    else:
                        self.stt_results_text.insert(tk.END, f"   Error: {trans['error']}\n")
                    self.stt_results_text.insert(tk.END, "\n")
                
                if results['speaker']:
                    speaker = results['speaker']
                    self.stt_results_text.insert(tk.END, f"👤 SPEAKER: {speaker['prediction']} ({speaker['confidence']:.1%})\n")
                
                if results['mood']:
                    mood = results['mood']
                    self.stt_results_text.insert(tk.END, f"😊 EMOTION: {mood['prediction']} ({mood['confidence']:.1%})\n")
                
                if results['esp32_sent']:
                    self.stt_results_text.insert(tk.END, f"📡 ESP32: ✅ Sent\n")
                
                self.stt_results_text.insert(tk.END, "\n")
                self.stt_results_text.see(tk.END)
                self.status_var.set("Live analysis completed")
                
            except Exception as e:
                self.stt_results_text.insert(tk.END, f"❌ Error: {e}\n\n")
                self.status_var.set("Live analysis error")
        
        threading.Thread(target=live_analysis_thread, daemon=True).start()
    
    # ESP32 Methods
    def test_esp32_connection(self):
        """Test ESP32 connection"""
        ip = self.esp32_ip_var.get()
        port = self.esp32_port_var.get()
        
        # Update ESP32 client settings
        self.identifier.esp32_client.host = ip
        self.identifier.esp32_client.port = port
        
        def test_thread():
            try:
                self.esp32_status_text.insert(tk.END, f"🔄 Testing connection to {ip}:{port}...\n")
                self.esp32_status_text.see(tk.END)
                
                success = self.identifier.esp32_client.test_connection()
                
                if success:
                    self.esp32_status_text.insert(tk.END, f"✅ Connection successful!\n")
                    messagebox.showinfo("Success", "ESP32 connection successful!")
                else:
                    self.esp32_status_text.insert(tk.END, f"❌ Connection failed!\n")
                    messagebox.showerror("Error", "ESP32 connection failed!")
                
                self.esp32_status_text.insert(tk.END, "\n")
                self.esp32_status_text.see(tk.END)
                
            except Exception as e:
                self.esp32_status_text.insert(tk.END, f"❌ Error: {e}\n\n")
                messagebox.showerror("Error", f"Connection test error: {e}")
        
        threading.Thread(target=test_thread, daemon=True).start()
    
    def enable_esp32_communication(self):
        """Enable ESP32 communication"""
        ip = self.esp32_ip_var.get()
        port = self.esp32_port_var.get()
        
        self.identifier.esp32_client.host = ip
        self.identifier.esp32_client.port = port
        self.identifier.enable_tcp_communication()
        
        self.esp32_status_text.insert(tk.END, f"✅ ESP32 communication enabled ({ip}:{port})\n\n")
        self.esp32_status_text.see(tk.END)
        
        messagebox.showinfo("Success", "ESP32 communication enabled!")
    
    def disable_esp32_communication(self):
        """Disable ESP32 communication"""
        self.identifier.disable_tcp_communication()
        
        self.esp32_status_text.insert(tk.END, f"❌ ESP32 communication disabled\n\n")
        self.esp32_status_text.see(tk.END)
        
        messagebox.showinfo("Info", "ESP32 communication disabled!")
    
    def send_manual_codes(self):
        """Send manual person and emotion codes to ESP32"""
        person_code = self.person_code_var.get()
        emotion_code = self.emotion_code_var.get()
        
        def send_thread():
            try:
                self.esp32_status_text.insert(tk.END, f"🔄 Sending codes: Person={person_code}, Emotion={emotion_code}\n")
                self.esp32_status_text.see(tk.END)
                
                success = self.identifier.esp32_client.send_simple_codes(person_code, emotion_code)
                
                if success:
                    self.esp32_status_text.insert(tk.END, f"✅ Codes sent successfully!\n")
                else:
                    self.esp32_status_text.insert(tk.END, f"❌ Failed to send codes!\n")
                
                self.esp32_status_text.insert(tk.END, "\n")
                self.esp32_status_text.see(tk.END)
                
            except Exception as e:
                self.esp32_status_text.insert(tk.END, f"❌ Error: {e}\n\n")
        
        threading.Thread(target=send_thread, daemon=True).start()

def main():
    root = tk.Tk()
    app = VoiceIdentifierGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
