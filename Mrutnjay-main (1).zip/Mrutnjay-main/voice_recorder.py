import pyaudio
import wave
import threading
import time
import os
from datetime import datetime

class VoiceRecorder:
    def __init__(self):
        self.chunk = 1024
        self.sample_format = pyaudio.paInt16
        self.channels = 1
        self.fs = 22050  # Sample rate
        self.recording = False
        self.frames = []
        
    def record_audio(self, duration=5, output_path="recording.wav"):
        """
        Record audio for a specified duration
        """
        p = pyaudio.PyAudio()
        
        print(f"Recording for {duration} seconds...")
        
        stream = p.open(format=self.sample_format,
                       channels=self.channels,
                       rate=self.fs,
                       frames_per_buffer=self.chunk,
                       input=True)
        
        frames = []
        
        # Record for the specified duration
        for i in range(0, int(self.fs / self.chunk * duration)):
            data = stream.read(self.chunk)
            frames.append(data)
        
        # Stop and close the stream
        stream.stop_stream()
        stream.close()
        p.terminate()
        
        # Save the recorded data as a WAV file
        wf = wave.open(output_path, 'wb')
        wf.setnchannels(self.channels)
        wf.setsampwidth(p.get_sample_size(self.sample_format))
        wf.setframerate(self.fs)
        wf.writeframes(b''.join(frames))
        wf.close()
        
        print(f"Recording saved to {output_path}")
        return output_path
    
    def start_recording(self):
        """
        Start recording (for manual stop)
        """
        if self.recording:
            print("Already recording!")
            return
        
        self.recording = True
        self.frames = []
        
        p = pyaudio.PyAudio()
        
        self.stream = p.open(format=self.sample_format,
                            channels=self.channels,
                            rate=self.fs,
                            frames_per_buffer=self.chunk,
                            input=True)
        
        print("Recording started... Press Enter to stop.")
        
        def record_thread():
            while self.recording:
                data = self.stream.read(self.chunk)
                self.frames.append(data)
        
        self.record_thread = threading.Thread(target=record_thread)
        self.record_thread.start()
        
        self.p = p
    
    def stop_recording(self, output_path="recording.wav"):
        """
        Stop recording and save file
        """
        if not self.recording:
            print("Not recording!")
            return None
        
        self.recording = False
        self.record_thread.join()
        
        # Stop and close the stream
        self.stream.stop_stream()
        self.stream.close()
        self.p.terminate()
        
        # Save the recorded data as a WAV file
        wf = wave.open(output_path, 'wb')
        wf.setnchannels(self.channels)
        wf.setsampwidth(self.p.get_sample_size(self.sample_format))
        wf.setframerate(self.fs)
        wf.writeframes(b''.join(self.frames))
        wf.close()
        
        print(f"Recording saved to {output_path}")
        return output_path
    
    def collect_voice_samples(self, speaker_name, num_samples=5, sample_duration=5):
        """
        Collect multiple voice samples for a speaker
        """
        # Create directory for the speaker
        speaker_dir = os.path.join("training_data", speaker_name)
        os.makedirs(speaker_dir, exist_ok=True)
        
        print(f"Collecting {num_samples} voice samples for {speaker_name}")
        print(f"Each recording will be {sample_duration} seconds long")
        
        for i in range(num_samples):
            input(f"\nPress Enter to start recording sample {i+1}/{num_samples}...")
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = os.path.join(speaker_dir, f"{speaker_name}_sample_{i+1}_{timestamp}.wav")
            
            self.record_audio(duration=sample_duration, output_path=output_path)
            print(f"Sample {i+1} completed!")
        
        print(f"\nAll samples collected for {speaker_name}")
        return speaker_dir

def main():
    """
    Interactive voice sample collection
    """
    recorder = VoiceRecorder()
    
    print("=== Voice Sample Collector ===")
    print("This tool helps you collect voice samples for training the voice identifier")
    
    while True:
        print("\nOptions:")
        print("1. Collect voice samples for a new speaker")
        print("2. Record a single audio file")
        print("3. Exit")
        
        choice = input("\nEnter your choice (1-3): ").strip()
        
        if choice == "1":
            speaker_name = input("Enter speaker name: ").strip()
            if not speaker_name:
                print("Please enter a valid speaker name")
                continue
            
            try:
                num_samples = int(input("Number of samples (default 5): ") or "5")
                duration = int(input("Duration per sample in seconds (default 5): ") or "5")
            except ValueError:
                print("Invalid input. Using defaults.")
                num_samples = 5
                duration = 5
            
            recorder.collect_voice_samples(speaker_name, num_samples, duration)
        
        elif choice == "2":
            filename = input("Enter filename (default: recording.wav): ").strip() or "recording.wav"
            try:
                duration = int(input("Duration in seconds (default 5): ") or "5")
            except ValueError:
                duration = 5
            
            recorder.record_audio(duration, filename)
        
        elif choice == "3":
            print("Goodbye!")
            break
        
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
