#!/usr/bin/env python3
"""
ESP32 Voice Analysis CLI
Command-line interface for sending voice analysis data to ESP32
"""

import argparse
import sys
import os
from voice_id import VoiceIdentifier

def send_codes_to_esp32(esp32_ip, esp32_port, person_code, emotion_code):
    """Send manual codes to ESP32"""
    print(f"Connecting to ESP32 at {esp32_ip}:{esp32_port}")
    
    identifier = VoiceIdentifier(esp32_ip, esp32_port)
    identifier.enable_tcp_communication()
    
    # Test connection
    success, message = identifier.test_esp32_connection()
    if not success:
        print(f"❌ Connection failed: {message}")
        return False
    
    print("✅ Connected to ESP32")
    
    # Send codes
    success = identifier.esp32_client.send_simple_codes(person_code, emotion_code)
    if success:
        print(f"✅ Sent codes - Person: {person_code}, Emotion: {emotion_code}")
    else:
        print("❌ Failed to send codes")
    
    identifier.disable_tcp_communication()
    return success

def analyze_and_send(esp32_ip, esp32_port, audio_file):
    """Analyze audio file and send results to ESP32"""
    if not os.path.exists(audio_file):
        print(f"❌ Audio file not found: {audio_file}")
        return False
    
    print(f"Analyzing audio file: {audio_file}")
    print(f"ESP32 target: {esp32_ip}:{esp32_port}")
    
    identifier = VoiceIdentifier(esp32_ip, esp32_port)
    identifier.enable_tcp_communication()
    
    # Test connection
    success, message = identifier.test_esp32_connection()
    if not success:
        print(f"❌ Connection failed: {message}")
        return False
    
    print("✅ Connected to ESP32")
    
    # Perform analysis and send
    success = identifier.analyze_and_send_to_esp32(audio_file)
    if success:
        print("✅ Analysis completed and sent to ESP32")
    else:
        print("❌ Failed to analyze or send to ESP32")
    
    identifier.disable_tcp_communication()
    return success

def main():
    parser = argparse.ArgumentParser(description="ESP32 Voice Analysis CLI")
    parser.add_argument("--ip", default="192.168.1.100", help="ESP32 IP address")
    parser.add_argument("--port", type=int, default=8080, help="ESP32 port")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Send codes command
    send_parser = subparsers.add_parser("send", help="Send manual codes to ESP32")
    send_parser.add_argument("person_code", type=int, choices=[0,1,2,3], 
                            help="Person code (0=Unknown, 1-3=Person1-3)")
    send_parser.add_argument("emotion_code", type=int, choices=[0,1,2,3,4,5],
                            help="Emotion code (0=Neutral, 1=Happy, 2=Sad, 3=Angry, 4=Calm, 5=Excited)")
    
    # Analyze command
    analyze_parser = subparsers.add_parser("analyze", help="Analyze audio file and send to ESP32")
    analyze_parser.add_argument("audio_file", help="Path to audio file")
    
    # Test command
    test_parser = subparsers.add_parser("test", help="Test ESP32 connection")
    
    args = parser.parse_args()
    
    if args.command == "send":
        success = send_codes_to_esp32(args.ip, args.port, args.person_code, args.emotion_code)
        sys.exit(0 if success else 1)
    
    elif args.command == "analyze":
        success = analyze_and_send(args.ip, args.port, args.audio_file)
        sys.exit(0 if success else 1)
    
    elif args.command == "test":
        identifier = VoiceIdentifier(args.ip, args.port)
        identifier.enable_tcp_communication()
        success, message = identifier.test_esp32_connection()
        print(message)
        identifier.disable_tcp_communication()
        sys.exit(0 if success else 1)
    
    else:
        parser.print_help()
        print("\nExamples:")
        print("  python esp32_cli.py send 1 2          # Send Person 1, Happy emotion")
        print("  python esp32_cli.py analyze audio.wav # Analyze audio and send results")
        print("  python esp32_cli.py test              # Test ESP32 connection")
        print("  python esp32_cli.py --ip 192.168.1.50 test  # Test with different IP")

if __name__ == "__main__":
    main()
