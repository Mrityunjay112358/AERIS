"""
Voice Mood Analyzer Module

This module analyzes the emotional state/mood from voice recordings.
It extracts prosodic and spectral features that correlate with emotions.
"""

import numpy as np
import librosa
import pickle
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import warnings
warnings.filterwarnings('ignore')

class VoiceMoodAnalyzer:
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.mood_labels = {}
        self.feature_dim = None
        
        # Default mood categories
        self.default_moods = {
            0: "Neutral",
            1: "Happy", 
            2: "Sad",
            3: "Angry",
            4: "Excited",
            5: "Calm"
        }
        
    def extract_mood_features(self, audio_path, sr=22050):
        """
        Extract features specifically for mood/emotion recognition
        """
        try:
            # Load audio
            y, sr = librosa.load(audio_path, sr=sr)
            
            # Remove silence for better analysis
            y_trimmed, _ = librosa.effects.trim(y, top_db=20)
            
            features = []
            
            # 1. Fundamental frequency (F0) features - pitch related
            try:
                f0 = librosa.yin(y_trimmed, fmin=50, fmax=400)
                f0 = f0[f0 > 0]  # Remove unvoiced frames
                if len(f0) > 0:
                    features.extend([
                        np.mean(f0),           # Average pitch
                        np.std(f0),            # Pitch variation
                        np.max(f0) - np.min(f0), # Pitch range
                        np.percentile(f0, 75) - np.percentile(f0, 25)  # IQR
                    ])
                else:
                    features.extend([0, 0, 0, 0])
            except:
                features.extend([0, 0, 0, 0])
            
            # 2. Energy and intensity features
            rms = librosa.feature.rms(y=y_trimmed)[0]
            features.extend([
                np.mean(rms),              # Average energy
                np.std(rms),               # Energy variation
                np.max(rms),               # Peak energy
                np.mean(rms**2)            # Power
            ])
            
            # 3. Tempo and rhythm features
            try:
                tempo, beats = librosa.beat.beat_track(y=y_trimmed, sr=sr)
                features.append(tempo)
                
                # Beat strength variation
                onset_env = librosa.onset.onset_strength(y=y_trimmed, sr=sr)
                features.append(np.std(onset_env))
            except:
                features.extend([120.0, 0.0])  # Default values
            
            # 4. Spectral features for emotion
            spectral_centroids = librosa.feature.spectral_centroid(y=y_trimmed, sr=sr)[0]
            spectral_rolloff = librosa.feature.spectral_rolloff(y=y_trimmed, sr=sr)[0]
            spectral_bandwidth = librosa.feature.spectral_bandwidth(y=y_trimmed, sr=sr)[0]
            zero_crossing_rate = librosa.feature.zero_crossing_rate(y_trimmed)[0]
            
            features.extend([
                np.mean(spectral_centroids),   # Brightness
                np.std(spectral_centroids),    # Spectral variation
                np.mean(spectral_rolloff),     # High-frequency content
                np.mean(spectral_bandwidth),   # Spectral spread
                np.mean(zero_crossing_rate),   # Roughness indicator
                np.std(zero_crossing_rate)
            ])
            
            # 5. MFCC features for emotional content
            mfccs = librosa.feature.mfcc(y=y_trimmed, sr=sr, n_mfcc=13)
            mfcc_mean = np.mean(mfccs, axis=1)
            mfcc_std = np.std(mfccs, axis=1)
            features.extend(mfcc_mean)
            features.extend(mfcc_std)
            
            # 6. Chroma features (harmonic content)
            try:
                chroma = librosa.feature.chroma_stft(y=y_trimmed, sr=sr)
                features.extend(np.mean(chroma, axis=1))
            except:
                features.extend([0.0] * 12)
            
            # 7. Prosodic features
            # Speech rate approximation
            onset_frames = librosa.onset.onset_detect(y=y_trimmed, sr=sr)
            speech_rate = len(onset_frames) / (len(y_trimmed) / sr)
            features.append(speech_rate)
            
            # Jitter (pitch perturbation) approximation
            try:
                if len(f0) > 1:
                    jitter = np.mean(np.abs(np.diff(f0)) / np.mean(f0))
                    features.append(jitter)
                else:
                    features.append(0.0)
            except:
                features.append(0.0)
            
            # Shimmer (amplitude perturbation) approximation
            shimmer = np.mean(np.abs(np.diff(rms)) / np.mean(rms)) if len(rms) > 1 else 0
            features.append(shimmer)
            
            # Ensure we have a consistent feature vector length
            features = np.array(features, dtype=np.float32)
            
            # Debug: print feature vector length
            if len(features) != 57:
                print(f"Warning: Feature vector length is {len(features)}, expected 57")
                # Pad or truncate to expected length
                if len(features) < 57:
                    features = np.pad(features, (0, 57 - len(features)), mode='constant')
                else:
                    features = features[:57]
            
            return features
            
        except Exception as e:
            print(f"Error extracting mood features from {audio_path}: {e}")
            # Return a default feature vector of the expected length
            return np.zeros(57, dtype=np.float32)
    
    def predict_mood(self, audio_path, return_probabilities=False):
        """
        Predict mood from audio file
        """
        if self.model is None:
            # Use a simple rule-based approach if no model is trained
            return self._rule_based_mood_prediction(audio_path)
        
        features = self.extract_mood_features(audio_path)
        if features is None or np.all(features == 0):
            return "Error processing audio", 0.0
        
        # Ensure feature dimensions match
        if len(features) != self.feature_dim:
            return f"Feature dimension mismatch. Expected {self.feature_dim}, got {len(features)}", 0.0
        
        features_scaled = self.scaler.transform([features])
        
        if return_probabilities and hasattr(self.model, 'predict_proba'):
            probabilities = self.model.predict_proba(features_scaled)[0]
            results = []
            for i, prob in enumerate(probabilities):
                mood = self.mood_labels.get(i, f"Mood_{i}")
                results.append((mood, prob))
            return sorted(results, key=lambda x: x[1], reverse=True)
        else:
            prediction = self.model.predict(features_scaled)[0]
            confidence = 0.8  # Default confidence for non-probabilistic models
            if hasattr(self.model, 'predict_proba'):
                confidence = np.max(self.model.predict_proba(features_scaled))
            mood = self.mood_labels.get(prediction, f"Mood_{prediction}")
            return mood, confidence
    
    def _rule_based_mood_prediction(self, audio_path):
        """
        Simple rule-based mood prediction when no trained model is available
        """
        features = self.extract_mood_features(audio_path)
        if features is None or np.all(features == 0):
            return "Error", 0.0
        
        # Extract key features for rule-based analysis
        avg_pitch = features[0]      # Average F0
        pitch_var = features[1]      # Pitch variation
        avg_energy = features[4]     # Average energy
        energy_var = features[5]     # Energy variation
        tempo = features[8]          # Tempo
        spectral_centroid = features[10]  # Brightness
        
        # Simple rules based on common acoustic correlates of emotion
        mood_scores = {
            "Happy": 0,
            "Sad": 0,
            "Angry": 0,
            "Calm": 0,
            "Excited": 0,
            "Neutral": 0
        }
        
        # High pitch often indicates happiness or excitement
        if avg_pitch > 200:
            mood_scores["Happy"] += 2
            mood_scores["Excited"] += 2
        elif avg_pitch < 150:
            mood_scores["Sad"] += 2
            mood_scores["Calm"] += 1
        
        # High pitch variation often indicates emotion
        if pitch_var > 30:
            mood_scores["Excited"] += 1
            mood_scores["Happy"] += 1
        elif pitch_var < 10:
            mood_scores["Calm"] += 2
            mood_scores["Sad"] += 1
        
        # High energy often indicates positive emotions or anger
        if avg_energy > 0.05:
            mood_scores["Excited"] += 2
            mood_scores["Angry"] += 1
            mood_scores["Happy"] += 1
        elif avg_energy < 0.02:
            mood_scores["Sad"] += 2
            mood_scores["Calm"] += 1
        
        # High energy variation indicates emotional expression
        if energy_var > 0.02:
            mood_scores["Angry"] += 2
            mood_scores["Excited"] += 1
        
        # Fast tempo often indicates excitement
        if tempo > 140:
            mood_scores["Excited"] += 1
            mood_scores["Happy"] += 1
        elif tempo < 90:
            mood_scores["Calm"] += 1
            mood_scores["Sad"] += 1
        
        # High spectral centroid indicates brightness/arousal
        if spectral_centroid > 2000:
            mood_scores["Happy"] += 1
            mood_scores["Excited"] += 1
        elif spectral_centroid < 1500:
            mood_scores["Sad"] += 1
            mood_scores["Calm"] += 1
        
        # Add neutral as baseline
        mood_scores["Neutral"] += 1
        
        # Find the mood with highest score
        predicted_mood = max(mood_scores, key=mood_scores.get)
        max_score = mood_scores[predicted_mood]
        confidence = min(0.95, max_score / 6.0)  # Normalize to reasonable confidence
        
        return predicted_mood, confidence
    
    def train_mood_model(self, data_folder):
        """
        Train mood classification model (if you have labeled mood data)
        """
        print("Note: Mood training requires labeled data organized by mood folders.")
        print("Using rule-based analysis for now.")
        return False
    
    def save_mood_model(self, model_path):
        """
        Save trained mood model
        """
        if self.model is None:
            print("No trained model to save. Using rule-based analysis.")
            return
        
        model_data = {
            'model': self.model,
            'scaler': self.scaler,
            'mood_labels': self.mood_labels,
            'feature_dim': self.feature_dim
        }
        with open(model_path, 'wb') as f:
            pickle.dump(model_data, f)
        print(f"Mood model saved to {model_path}")
    
    def load_mood_model(self, model_path):
        """
        Load pre-trained mood model
        """
        try:
            with open(model_path, 'rb') as f:
                model_data = pickle.load(f)
            
            self.model = model_data['model']
            self.scaler = model_data['scaler']
            self.mood_labels = model_data['mood_labels']
            self.feature_dim = model_data['feature_dim']
            print(f"Mood model loaded from {model_path}")
            print(f"Available moods: {list(self.mood_labels.values())}")
        except Exception as e:
            print(f"Error loading mood model: {e}")
            print("Using rule-based mood analysis instead.")

if __name__ == "__main__":
    # Example usage
    analyzer = VoiceMoodAnalyzer()
    
    # Test with an audio file
    # mood, confidence = analyzer.predict_mood("test_audio.wav")
    # print(f"Predicted mood: {mood} (confidence: {confidence:.2%})")
    
    print("Voice Mood Analyzer module loaded successfully!")
    print("Available moods for analysis:", list(analyzer.default_moods.values()))
