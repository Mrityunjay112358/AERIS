#!/usr/bin/env python3
"""
Speech-to-Text Command Line Interface
Complete voice analysis with speech-to-text integration
"""

import argparse
import sys
import os
from voice_id import VoiceIdentifier
from speech_to_text import SpeechToTextConverter

def main():
    parser = argparse.ArgumentParser(description='Speech-to-Text Voice Analysis CLI')
    parser.add_argument('--ip', default='192.168.1.100', help='ESP32 IP address')
    parser.add_argument('--port', type=int, default=8080, help='ESP32 port')
    parser.add_argument('--engine', default='google', choices=['google', 'sphinx', 'wit'], help='Speech recognition engine')
    parser.add_argument('--language', default='en-US', help='Language code (e.g., en-US, es-ES)')
    parser.add_argument('--model', help='Path to trained voice model')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Transcribe command
    transcribe_parser = subparsers.add_parser('transcribe', help='Transcribe audio file')
    transcribe_parser.add_argument('audio_file', help='Path to audio file')
    transcribe_parser.add_argument('--quality', action='store_true', help='Analyze audio quality')
    
    # Live command
    live_parser = subparsers.add_parser('live', help='Live recording and analysis')
    live_parser.add_argument('--duration', type=int, default=5, help='Recording duration in seconds')
    live_parser.add_argument('--no-transcription', action='store_true', help='Disable transcription')
    live_parser.add_argument('--esp32', action='store_true', help='Send results to ESP32')
    
    # Complete analysis command
    analyze_parser = subparsers.add_parser('analyze', help='Complete voice analysis (speaker + emotion + transcription)')
    analyze_parser.add_argument('audio_file', help='Path to audio file')
    analyze_parser.add_argument('--esp32', action='store_true', help='Send results to ESP32')
    
    # Test transcription command
    test_parser = subparsers.add_parser('test-stt', help='Test speech-to-text engines')
    test_parser.add_argument('--audio', help='Test with audio file (optional)')
    
    # Languages command
    lang_parser = subparsers.add_parser('languages', help='List supported languages')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # Initialize voice identifier
    identifier = VoiceIdentifier(args.ip, args.port)
    
    # Set speech-to-text configuration
    identifier.enable_speech_to_text(args.engine, args.language)
    
    # Load model if specified
    if args.model and os.path.exists(args.model):
        try:
            identifier.load_model(args.model)
            print(f"✅ Loaded voice model: {args.model}")
        except Exception as e:
            print(f"❌ Failed to load model: {e}")
    
    # Execute commands
    if args.command == 'transcribe':
        transcribe_audio_file(identifier, args.audio_file, args.quality)
        
    elif args.command == 'live':
        live_analysis(identifier, args.duration, not args.no_transcription, args.esp32)
        
    elif args.command == 'analyze':
        complete_analysis(identifier, args.audio_file, args.esp32)
        
    elif args.command == 'test-stt':
        test_speech_to_text(identifier, args.audio)
        
    elif args.command == 'languages':
        list_supported_languages(identifier)

def transcribe_audio_file(identifier, audio_file, analyze_quality=False):
    """Transcribe an audio file to text"""
    if not os.path.exists(audio_file):
        print(f"❌ Audio file not found: {audio_file}")
        return
    
    print(f"🔄 Transcribing audio file: {audio_file}")
    print(f"🔧 Engine: {identifier.stt_engine}, Language: {identifier.stt_language}")
    print()
    
    # Analyze quality if requested
    if analyze_quality:
        print("📊 Analyzing audio quality...")
        quality = identifier.speech_to_text.analyze_speech_quality(audio_file)
        
        if 'error' not in quality:
            print(f"   Duration: {quality['duration_seconds']:.1f}s")
            print(f"   Sample Rate: {quality['sample_rate']} Hz")
            print(f"   Quality Score: {quality['quality_score']:.1f}/100 ({quality['assessment']})")
            print(f"   Estimated SNR: {quality['estimated_snr_db']:.1f} dB")
            print()
        else:
            print(f"   {quality['error']}")
            print()
    
    # Perform transcription
    result = identifier.transcribe_audio_file(audio_file)
    
    if result['success']:
        print("✅ Transcription Results:")
        print("=" * 50)
        print(f"📝 Text: {result['transcription']}")
        print(f"📊 Confidence: {result['confidence']:.1%}")
        print(f"🔧 Engine: {result['engine']}")
        print(f"🌐 Language: {result['language']}")
    else:
        print(f"❌ Transcription failed: {result['error']}")

def live_analysis(identifier, duration, include_transcription, send_to_esp32):
    """Perform live recording and analysis"""
    print(f"🎤 Starting live analysis...")
    print(f"⏱️  Recording duration: {duration} seconds")
    print(f"📝 Transcription: {'Enabled' if include_transcription else 'Disabled'}")
    print(f"📡 ESP32: {'Enabled' if send_to_esp32 else 'Disabled'}")
    print()
    
    if send_to_esp32:
        identifier.enable_tcp_communication()
    
    try:
        results = identifier.record_and_analyze_live(duration, include_transcription)
        
        print("📊 Analysis Results:")
        print("=" * 50)
        
        if results['transcription'] and include_transcription:
            trans = results['transcription']
            if trans['success']:
                print(f"📝 Transcription: {trans['transcription']}")
                print(f"   Confidence: {trans['confidence']:.1%}")
            else:
                print(f"📝 Transcription failed: {trans['error']}")
            print()
        
        if results['speaker']:
            speaker = results['speaker']
            print(f"👤 Speaker: {speaker['prediction']}")
            print(f"   Confidence: {speaker['confidence']:.1%}")
            print()
        
        if results['mood']:
            mood = results['mood']
            print(f"😊 Emotion: {mood['prediction']}")
            print(f"   Confidence: {mood['confidence']:.1%}")
            print()
        
        if send_to_esp32:
            if results['esp32_sent']:
                print("✅ Data sent to ESP32 successfully")
            else:
                print("❌ Failed to send data to ESP32")
        
    except KeyboardInterrupt:
        print("\\n⏹️  Recording interrupted by user")
    except Exception as e:
        print(f"❌ Error during live analysis: {e}")

def complete_analysis(identifier, audio_file, send_to_esp32):
    """Perform complete analysis of audio file"""
    if not os.path.exists(audio_file):
        print(f"❌ Audio file not found: {audio_file}")
        return
    
    print(f"🔄 Analyzing audio file: {audio_file}")
    print("=" * 50)
    
    if send_to_esp32:
        identifier.enable_tcp_communication()
        print("📡 ESP32 communication enabled")
    
    results = identifier.analyze_with_transcription(audio_file)
    
    print("\\n📊 Complete Analysis Results:")
    print("=" * 50)
    
    # Transcription results
    if results['transcription']:
        trans = results['transcription']
        if trans['success']:
            print(f"📝 Transcription: \"{trans['transcription']}\"")
            print(f"   Confidence: {trans['confidence']:.1%}")
            print(f"   Engine: {trans['engine']}")
        else:
            print(f"📝 Transcription failed: {trans['error']}")
        print()
    
    # Speaker identification
    if results['speaker']:
        speaker = results['speaker']
        print(f"👤 Speaker: {speaker['prediction']}")
        print(f"   Confidence: {speaker['confidence']:.1%}")
        print()
    else:
        print("👤 Speaker identification: No model loaded")
        print()
    
    # Emotion analysis
    if results['mood']:
        mood = results['mood']
        print(f"😊 Emotion: {mood['prediction']}")
        print(f"   Confidence: {mood['confidence']:.1%}")
        print()
    
    # ESP32 status
    if send_to_esp32:
        if results['esp32_sent']:
            print("✅ Complete analysis sent to ESP32")
        else:
            print("❌ Failed to send data to ESP32")
    
    print(f"🎯 Overall Success: {'✅ Yes' if results['success'] else '❌ No'}")

def test_speech_to_text(identifier, test_audio=None):
    """Test different speech-to-text engines"""
    print("🧪 Testing Speech-to-Text Engines")
    print("=" * 50)
    
    engines = ['google', 'sphinx']
    
    if test_audio and os.path.exists(test_audio):
        print(f"📁 Testing with audio file: {test_audio}")
        print()
        
        for engine in engines:
            print(f"🔧 Testing {engine} engine...")
            identifier.enable_speech_to_text(engine, identifier.stt_language)
            
            result = identifier.transcribe_audio_file(test_audio)
            
            if result['success']:
                print(f"   ✅ {engine}: \"{result['transcription']}\" ({result['confidence']:.1%})")
            else:
                print(f"   ❌ {engine}: {result['error']}")
            print()
    else:
        print("🎤 Testing with microphone (5 seconds each)...")
        print("Say something when prompted...")
        print()
        
        for engine in engines:
            print(f"🔧 Testing {engine} engine - speak now...")
            identifier.enable_speech_to_text(engine, identifier.stt_language)
            
            result = identifier.transcribe_microphone(5)
            
            if result['success']:
                print(f"   ✅ {engine}: \"{result['transcription']}\" ({result['confidence']:.1%})")
            else:
                print(f"   ❌ {engine}: {result['error']}")
            print()

def list_supported_languages(identifier):
    """List all supported languages"""
    print("🌐 Supported Languages for Speech Recognition")
    print("=" * 60)
    
    languages = identifier.speech_to_text.get_supported_languages()
    
    print("Code      | Language")
    print("-" * 60)
    
    for code, name in sorted(languages.items()):
        print(f"{code:<9} | {name}")
    
    print()
    print(f"Current setting: {identifier.stt_language}")

if __name__ == "__main__":
    main()
