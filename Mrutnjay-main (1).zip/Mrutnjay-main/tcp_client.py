import socket
import json
import threading
import time
from typing import Dict, Optional, Tuple

class ESP32TCPClient:
    def __init__(self, host: str = "192.168.1.100", port: int = 8080):
        """
        Initialize TCP client for ESP32 communication
        
        Args:
            host: ESP32 IP address
            port: ESP32 listening port
        """
        self.host = host
        self.port = port
        self.socket = None
        self.connected = False
        self.connection_lock = threading.Lock()
        
        # Mapping for person codes (can be customized)
        self.person_codes = {
            "unknown": 0,
            "person1": 1,
            "person2": 2,
            "person3": 3,
            "hitendra": 1,  # Example mapping
            # Add more mappings as needed
        }
        
        # Mapping for emotion codes
        self.emotion_codes = {
            "Neutral": 0,
            "Happy": 1,
            "Sad": 2,
            "Angry": 3,
            "Calm": 4,
            "Excited": 5
        }
    
    def connect(self) -> bool:
        """
        Establish connection to ESP32
        
        Returns:
            bool: True if connected successfully
        """
        with self.connection_lock:
            try:
                if self.connected:
                    return True
                
                self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.socket.settimeout(5)  # 5 second timeout
                self.socket.connect((self.host, self.port))
                self.connected = True
                print(f"Connected to ESP32 at {self.host}:{self.port}")
                return True
                
            except Exception as e:
                print(f"Failed to connect to ESP32: {e}")
                self.connected = False
                if self.socket:
                    try:
                        self.socket.close()
                    except:
                        pass
                    self.socket = None
                return False
    
    def disconnect(self):
        """
        Disconnect from ESP32
        """
        with self.connection_lock:
            if self.socket:
                try:
                    self.socket.close()
                except:
                    pass
                self.socket = None
            self.connected = False
            print("Disconnected from ESP32")
    
    def send_data(self, person_code: int, emotion_code: int, confidence_person: float = 0.0, confidence_emotion: float = 0.0) -> bool:
        """
        Send person and emotion codes to ESP32
        
        Args:
            person_code: Person identification code (0-3)
            emotion_code: Emotion code (0-5)
            confidence_person: Person identification confidence (0.0-1.0)
            confidence_emotion: Emotion confidence (0.0-1.0)
            
        Returns:
            bool: True if sent successfully
        """
        if not self.connected:
            if not self.connect():
                return False
        
        try:
            # Create data packet
            data_packet = {
                "person": max(0, min(3, person_code)),  # Clamp to 0-3
                "emotion": max(0, min(5, emotion_code)),  # Clamp to 0-5
                "confidence_person": round(confidence_person * 100, 1),  # Convert to percentage
                "confidence_emotion": round(confidence_emotion * 100, 1),
                "timestamp": int(time.time())
            }
            
            # Convert to JSON and encode
            json_data = json.dumps(data_packet)
            message = json_data + "\n"  # Add newline delimiter
            
            with self.connection_lock:
                if self.socket:
                    self.socket.send(message.encode('utf-8'))
                    print(f"Sent to ESP32: Person={person_code}, Emotion={emotion_code}")
                    return True
                    
        except Exception as e:
            print(f"Failed to send data to ESP32: {e}")
            self.connected = False
            return False
        
        return False
    
    def send_simple_codes(self, person_code: int, emotion_code: int) -> bool:
        """
        Send simple numeric codes to ESP32 (simplified format)
        
        Args:
            person_code: Person code (0-3)
            emotion_code: Emotion code (0-5)
            
        Returns:
            bool: True if sent successfully
        """
        if not self.connected:
            if not self.connect():
                return False
        
        try:
            # Simple format: "P:1,E:2\n"
            message = f"P:{max(0, min(3, person_code))},E:{max(0, min(5, emotion_code))}\n"
            
            with self.connection_lock:
                if self.socket:
                    self.socket.send(message.encode('utf-8'))
                    print(f"Sent simple codes to ESP32: {message.strip()}")
                    return True
                    
        except Exception as e:
            print(f"Failed to send simple codes to ESP32: {e}")
            self.connected = False
            return False
        
        return False
    
    def get_person_code(self, person_name: str) -> int:
        """
        Get numeric code for person name
        
        Args:
            person_name: Name of the person
            
        Returns:
            int: Person code (0-3)
        """
        # Convert to lowercase for case-insensitive matching
        person_lower = person_name.lower()
        
        # Check direct mapping first
        if person_lower in self.person_codes:
            return self.person_codes[person_lower]
        
        # Check if name contains known persons
        for known_person, code in self.person_codes.items():
            if known_person in person_lower or person_lower in known_person:
                return code
        
        # Default to unknown person
        return 0
    
    def get_emotion_code(self, emotion_name: str) -> int:
        """
        Get numeric code for emotion name
        
        Args:
            emotion_name: Name of the emotion
            
        Returns:
            int: Emotion code (0-5)
        """
        return self.emotion_codes.get(emotion_name, 0)  # Default to Neutral
    
    def send_analysis_result(self, person_name: str, emotion_name: str, 
                           confidence_person: float = 0.0, confidence_emotion: float = 0.0, 
                           simple_format: bool = True) -> bool:
        """
        Send complete analysis result to ESP32
        
        Args:
            person_name: Identified person name
            emotion_name: Detected emotion name
            confidence_person: Person identification confidence
            confidence_emotion: Emotion detection confidence
            simple_format: Use simple format (True) or JSON format (False)
            
        Returns:
            bool: True if sent successfully
        """
        person_code = self.get_person_code(person_name)
        emotion_code = self.get_emotion_code(emotion_name)
        
        if simple_format:
            return self.send_simple_codes(person_code, emotion_code)
        else:
            return self.send_data(person_code, emotion_code, confidence_person, confidence_emotion)
    
    def update_person_mapping(self, person_name: str, code: int):
        """
        Update person name to code mapping
        
        Args:
            person_name: Person name
            code: Numeric code (1-3)
        """
        if 1 <= code <= 3:
            self.person_codes[person_name.lower()] = code
            print(f"Updated person mapping: {person_name} -> {code}")
    
    def get_connection_status(self) -> Tuple[bool, str]:
        """
        Get current connection status
        
        Returns:
            Tuple[bool, str]: (connected, status_message)
        """
        if self.connected:
            return True, f"Connected to {self.host}:{self.port}"
        else:
            return False, "Not connected"
    
    def test_connection(self) -> bool:
        """
        Test connection to ESP32
        
        Returns:
            bool: True if connection test successful
        """
        if self.connect():
            # Send test message
            test_result = self.send_simple_codes(0, 0)  # Send neutral values
            return test_result
        return False
    
    def send_complete_analysis(self, person_name: str, emotion_name: str, 
                             transcription: str = "", confidence_person: float = 0.0, 
                             confidence_emotion: float = 0.0, confidence_transcription: float = 0.0) -> bool:
        """
        Send complete analysis results including transcription to ESP32
        
        Args:
            person_name: Name of the identified person
            emotion_name: Name of the identified emotion
            transcription: Speech-to-text transcription
            confidence_person: Person identification confidence (0.0-1.0)
            confidence_emotion: Emotion confidence (0.0-1.0)
            confidence_transcription: Transcription confidence (0.0-1.0)
            
        Returns:
            bool: True if sent successfully
        """
        try:
            # Create extended JSON message with transcription
            message = {
                "person": self.get_person_code(person_name),
                "emotion": self.get_emotion_code(emotion_name),
                "person_name": person_name,
                "emotion_name": emotion_name,
                "transcription": transcription,
                "confidence_person": confidence_person * 100,
                "confidence_emotion": confidence_emotion * 100,
                "confidence_transcription": confidence_transcription * 100,
                "timestamp": int(time.time()),
                "type": "complete_analysis"
            }
            
            return self.send_json_data(message)
            
        except Exception as e:
            print(f"Error sending complete analysis: {e}")
            return False
    
    def send_transcription(self, transcription: str, confidence: float = 0.0) -> bool:
        """
        Send only transcription data to ESP32
        
        Args:
            transcription: Speech-to-text transcription
            confidence: Transcription confidence (0.0-1.0)
            
        Returns:
            bool: True if sent successfully
        """
        try:
            # Create transcription-only JSON message
            data = {
                "type": "transcription",
                "transcription": transcription,
                "confidence": confidence * 100,
                "timestamp": int(time.time())
            }
            
            return self.send_json_data(data)
            
        except Exception as e:
            print(f"Error sending transcription: {e}")
            return False

# Example usage and testing
if __name__ == "__main__":
    # Example usage
    esp32_client = ESP32TCPClient("192.168.1.100", 8080)  # Update with your ESP32 IP
    
    # Test connection
    if esp32_client.test_connection():
        print("ESP32 connection test successful!")
        
        # Send some test data
        esp32_client.send_analysis_result("hitendra", "Happy", 0.85, 0.92)
        time.sleep(1)
        esp32_client.send_analysis_result("person2", "Excited", 0.78, 0.88)
        time.sleep(1)
        esp32_client.send_analysis_result("unknown", "Calm", 0.45, 0.75)
        
        # Test complete analysis with transcription
        esp32_client.send_complete_analysis("hitendra", "Happy", "Hello, how are you today?", 0.85, 0.92, 0.88)
        
    else:
        print("ESP32 connection test failed!")
    
    esp32_client.disconnect()
