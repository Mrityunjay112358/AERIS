import speech_recognition as sr
import os
import tempfile
from pydub import AudioSegment
import numpy as np

class SpeechToTextConverter:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.supported_engines = {
            'google': 'Google Speech Recognition (online)',
            'sphinx': 'CMU Sphinx (offline)',
            'wit': 'Wit.ai (online)',
            'azure': 'Microsoft Azure (online)',
            'houndify': 'Houndify (online)',
            'ibm': 'IBM Watson (online)'
        }
        self.default_engine = 'google'
        
    def convert_audio_to_wav(self, audio_path):
        """Convert various audio formats to WAV for speech recognition"""
        try:
            # Get file extension
            _, ext = os.path.splitext(audio_path.lower())
            
            if ext == '.wav':
                return audio_path
            
            # Load audio with pydub
            if ext == '.mp3':
                audio = AudioSegment.from_mp3(audio_path)
            elif ext == '.m4a':
                audio = AudioSegment.from_file(audio_path, format="m4a")
            elif ext == '.flac':
                audio = AudioSegment.from_file(audio_path, format="flac")
            elif ext == '.ogg':
                audio = AudioSegment.from_ogg(audio_path)
            else:
                # Try to load as generic audio file
                audio = AudioSegment.from_file(audio_path)
            
            # Convert to WAV and save to temporary file
            temp_wav = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
            audio.export(temp_wav.name, format='wav')
            return temp_wav.name
            
        except Exception as e:
            print(f"Error converting audio: {e}")
            return None
    
    def transcribe_audio(self, audio_path, engine='google', language='en-US'):
        """
        Convert speech to text from audio file
        
        Args:
            audio_path (str): Path to audio file
            engine (str): Speech recognition engine to use
            language (str): Language code (e.g., 'en-US', 'es-ES', 'fr-FR')
        
        Returns:
            dict: Contains transcription, confidence, and metadata
        """
        result = {
            'transcription': '',
            'confidence': 0.0,
            'engine': engine,
            'language': language,
            'success': False,
            'error': None
        }
        
        try:
            # Convert audio to WAV if needed
            wav_path = self.convert_audio_to_wav(audio_path)
            if not wav_path:
                result['error'] = "Could not convert audio to WAV format"
                return result
            
            # Load audio file
            with sr.AudioFile(wav_path) as source:
                # Adjust for ambient noise
                self.recognizer.adjust_for_ambient_noise(source)
                # Record the audio
                audio_data = self.recognizer.record(source)
            
            # Perform speech recognition based on selected engine
            if engine == 'google':
                transcription = self.recognizer.recognize_google(
                    audio_data, 
                    language=language,
                    show_all=True
                )
                
                if transcription and 'alternative' in transcription:
                    # Get best alternative
                    best_result = transcription['alternative'][0]
                    result['transcription'] = best_result.get('transcript', '')
                    result['confidence'] = best_result.get('confidence', 0.0)
                    result['success'] = True
                else:
                    result['error'] = "No speech detected or recognition failed"
                    
            elif engine == 'sphinx':
                transcription = self.recognizer.recognize_sphinx(audio_data)
                result['transcription'] = transcription
                result['confidence'] = 0.8  # Sphinx doesn't provide confidence
                result['success'] = True
                
            elif engine == 'wit':
                # Requires Wit.ai API key
                transcription = self.recognizer.recognize_wit(audio_data)
                result['transcription'] = transcription
                result['confidence'] = 0.8
                result['success'] = True
                
            else:
                result['error'] = f"Unsupported engine: {engine}"
            
            # Clean up temporary file if created
            if wav_path != audio_path and os.path.exists(wav_path):
                os.unlink(wav_path)
                
        except sr.UnknownValueError:
            result['error'] = "Speech recognition could not understand audio"
        except sr.RequestError as e:
            result['error'] = f"Could not request results from speech recognition service: {e}"
        except FileNotFoundError:
            result['error'] = f"Audio file not found: {audio_path}"
        except Exception as e:
            result['error'] = f"Unexpected error: {e}"
        
        return result
    
    def transcribe_microphone(self, duration=5, engine='google', language='en-US'):
        """
        Record from microphone and convert speech to text
        
        Args:
            duration (int): Recording duration in seconds
            engine (str): Speech recognition engine to use
            language (str): Language code
        
        Returns:
            dict: Contains transcription and metadata
        """
        result = {
            'transcription': '',
            'confidence': 0.0,
            'engine': engine,
            'language': language,
            'success': False,
            'error': None
        }
        
        try:
            # Use microphone as audio source
            with sr.Microphone() as source:
                print(f"🎤 Listening for {duration} seconds...")
                
                # Adjust for ambient noise
                self.recognizer.adjust_for_ambient_noise(source, duration=1)
                
                # Record audio
                audio_data = self.recognizer.listen(source, timeout=duration, phrase_time_limit=duration)
                
                print("🔄 Processing speech...")
                
            # Perform speech recognition
            if engine == 'google':
                transcription = self.recognizer.recognize_google(
                    audio_data, 
                    language=language,
                    show_all=True
                )
                
                if transcription and 'alternative' in transcription:
                    best_result = transcription['alternative'][0]
                    result['transcription'] = best_result.get('transcript', '')
                    result['confidence'] = best_result.get('confidence', 0.0)
                    result['success'] = True
                else:
                    result['error'] = "No speech detected"
                    
            elif engine == 'sphinx':
                transcription = self.recognizer.recognize_sphinx(audio_data)
                result['transcription'] = transcription
                result['confidence'] = 0.8
                result['success'] = True
                
        except sr.WaitTimeoutError:
            result['error'] = "No speech detected within timeout period"
        except sr.UnknownValueError:
            result['error'] = "Could not understand the speech"
        except sr.RequestError as e:
            result['error'] = f"Speech recognition service error: {e}"
        except Exception as e:
            result['error'] = f"Microphone error: {e}"
        
        return result
    
    def get_supported_languages(self):
        """Get list of supported language codes"""
        return {
            'en-US': 'English (US)',
            'en-GB': 'English (UK)',
            'es-ES': 'Spanish (Spain)',
            'es-MX': 'Spanish (Mexico)',
            'fr-FR': 'French (France)',
            'de-DE': 'German (Germany)',
            'it-IT': 'Italian (Italy)',
            'pt-BR': 'Portuguese (Brazil)',
            'ru-RU': 'Russian (Russia)',
            'ja-JP': 'Japanese (Japan)',
            'ko-KR': 'Korean (South Korea)',
            'zh-CN': 'Chinese (Simplified)',
            'zh-TW': 'Chinese (Traditional)',
            'hi-IN': 'Hindi (India)',
            'ar-SA': 'Arabic (Saudi Arabia)',
            'nl-NL': 'Dutch (Netherlands)',
            'sv-SE': 'Swedish (Sweden)',
            'da-DK': 'Danish (Denmark)',
            'no-NO': 'Norwegian (Norway)',
            'fi-FI': 'Finnish (Finland)'
        }
    
    def analyze_speech_quality(self, audio_path):
        """
        Analyze audio quality for speech recognition
        
        Returns:
            dict: Audio quality metrics
        """
        try:
            import librosa
            
            # Load audio
            y, sr = librosa.load(audio_path)
            
            # Calculate metrics
            rms_energy = np.sqrt(np.mean(y**2))
            zero_crossing_rate = np.mean(librosa.feature.zero_crossing_rate(y))
            spectral_centroid = np.mean(librosa.feature.spectral_centroid(y=y, sr=sr))
            
            # Estimate SNR (simplified)
            signal_power = np.mean(y**2)
            noise_power = np.var(y - np.mean(y))
            snr_estimate = 10 * np.log10(signal_power / max(noise_power, 1e-10))
            
            quality = {
                'rms_energy': float(rms_energy),
                'zero_crossing_rate': float(zero_crossing_rate),
                'spectral_centroid': float(spectral_centroid),
                'estimated_snr_db': float(snr_estimate),
                'duration_seconds': len(y) / sr,
                'sample_rate': sr,
                'quality_score': min(100, max(0, snr_estimate * 10))  # 0-100 scale
            }
            
            # Quality assessment
            if quality['quality_score'] > 80:
                quality['assessment'] = 'Excellent'
            elif quality['quality_score'] > 60:
                quality['assessment'] = 'Good'
            elif quality['quality_score'] > 40:
                quality['assessment'] = 'Fair'
            else:
                quality['assessment'] = 'Poor'
                
            return quality
            
        except Exception as e:
            return {'error': f"Could not analyze audio quality: {e}"}

# Example usage
if __name__ == "__main__":
    converter = SpeechToTextConverter()
    
    # Test with microphone
    print("Testing speech-to-text with microphone...")
    result = converter.transcribe_microphone(duration=5)
    
    if result['success']:
        print(f"✅ Transcription: {result['transcription']}")
        print(f"📊 Confidence: {result['confidence']:.2%}")
    else:
        print(f"❌ Error: {result['error']}")
