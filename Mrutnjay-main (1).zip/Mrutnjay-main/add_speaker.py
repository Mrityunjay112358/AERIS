#!/usr/bin/env python3
"""
Quick Voice Sample Collector

This script helps you quickly add voice samples for additional speakers
so you can test the voice identification training.
"""

import os
from voice_recorder import VoiceRecorder

def collect_samples_for_new_speaker():
    """
    Collect voice samples for a new speaker
    """
    recorder = VoiceRecorder()
    
    print("=== Quick Voice Sample Collection ===")
    print("This will help you add a second speaker to test training.")
    print()
    
    # Get speaker name
    while True:
        speaker_name = input("Enter name for the new speaker: ").strip()
        if speaker_name and speaker_name.lower() != 'priya':
            break
        elif speaker_name.lower() == 'priya':
            print("You already have samples for Priya. Please enter a different name.")
        else:
            print("Please enter a valid name.")
    
    print(f"\nCollecting 3 voice samples for {speaker_name}")
    print("Each recording will be 5 seconds long.")
    print("You can say anything - count numbers, read text, or speak naturally.")
    print()
    
    try:
        # Create the speaker directory
        speaker_dir = os.path.join("training_data", speaker_name)
        os.makedirs(speaker_dir, exist_ok=True)
        
        for i in range(3):
            input(f"Press Enter to record sample {i+1}/3 for {speaker_name}...")
            
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = os.path.join(speaker_dir, f"{speaker_name}_sample_{i+1}_{timestamp}.wav")
            
            print(f"Recording sample {i+1}... (5 seconds)")
            recorder.record_audio(duration=5, output_path=filename)
            print(f"✓ Sample {i+1} saved!")
            print()
        
        print(f"🎉 All samples collected for {speaker_name}!")
        print()
        print("Now you can:")
        print("1. Run the GUI: python voice_app_gui.py")
        print("2. Go to the Training tab")
        print("3. Click 'Use Default' to set the training folder")
        print("4. Click 'Train Model' to train with both speakers")
        print()
        print(f"Training data structure:")
        print(f"training_data/")
        print(f"├── Priya/ (5 samples)")
        print(f"└── {speaker_name}/ (3 samples)")
        
    except KeyboardInterrupt:
        print("\nCollection interrupted.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    collect_samples_for_new_speaker()
