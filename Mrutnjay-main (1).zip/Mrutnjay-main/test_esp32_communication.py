#!/usr/bin/env python3
"""
ESP32 Communication Test Script
Tests voice analysis with TCP communication to ESP32
"""

import os
import sys
import time
from voice_id import VoiceIdentifier

def test_esp32_communication():
    """
    Test ESP32 TCP communication functionality
    """
    print("🚀 ESP32 Communication Test")
    print("=" * 50)
    
    # Initialize voice identifier with ESP32 settings
    # Update these with your ESP32's actual IP address
    esp32_ip = "192.168.1.100"  # Change this to your ESP32's IP
    esp32_port = 8080
    
    identifier = VoiceIdentifier(esp32_ip, esp32_port)
    
    # Test 1: Enable TCP communication
    print("\n1️⃣ Enabling TCP communication...")
    identifier.enable_tcp_communication()
    
    # Test 2: Test connection
    print("\n2️⃣ Testing ESP32 connection...")
    success, message = identifier.test_esp32_connection()
    print(f"Connection test: {message}")
    
    if not success:
        print("❌ ESP32 connection failed!")
        print("Make sure:")
        print(f"  • ESP32 is connected to WiFi")
        print(f"  • ESP32 is running TCP server on {esp32_ip}:{esp32_port}")
        print(f"  • IP address is correct")
        print(f"  • ESP32 Arduino code is loaded and running")
        return False
    
    print("✅ ESP32 connected successfully!")
    
    # Test 3: Update person mappings
    print("\n3️⃣ Setting up person mappings...")
    identifier.update_esp32_person_mapping("hitendra", 1)
    identifier.update_esp32_person_mapping("person2", 2)
    identifier.update_esp32_person_mapping("person3", 3)
    
    # Test 4: Send manual test codes
    print("\n4️⃣ Sending test codes...")
    
    test_cases = [
        ("hitendra", "Happy"),
        ("person2", "Excited"), 
        ("unknown", "Calm"),
        ("hitendra", "Angry"),
        ("person3", "Sad"),
        ("person2", "Neutral")
    ]
    
    for person, emotion in test_cases:
        print(f"Sending: {person} -> {emotion}")
        success = identifier.send_to_esp32(person, emotion, 0.85, 0.92)
        if success:
            print(f"  ✅ Sent successfully")
        else:
            print(f"  ❌ Failed to send")
        time.sleep(2)  # 2 second delay for ESP32 display to update
    
    # Test 5: Test with real audio file (if available)
    print("\n5️⃣ Testing with audio file...")
    
    # Look for audio files in current directory
    audio_files = []
    for file in os.listdir('.'):
        if file.endswith(('.wav', '.mp3', '.flac', '.m4a')):
            audio_files.append(file)
    
    if audio_files:
        test_file = audio_files[0]
        print(f"Using audio file: {test_file}")
        
        # Test mood analysis only (doesn't require trained model)
        print("Testing mood analysis...")
        try:
            mood_result = identifier.mood_analyzer.predict_mood(test_file)
            print(f"Mood result: {mood_result}")
            
            if isinstance(mood_result, tuple):
                mood, confidence = mood_result
                print(f"Sending mood to ESP32: {mood}")
                identifier.send_to_esp32("test_person", mood, 0.5, confidence)
                time.sleep(2)
        except Exception as e:
            print(f"Audio test failed: {e}")
    else:
        print("No audio files found for testing")
    
    # Test 6: Test Speech-to-Text integration (if enabled)
    print("\n6️⃣ Testing Speech-to-Text integration...")
    
    if audio_files:
        test_file = audio_files[0]
        print(f"Testing STT with: {test_file}")
        
        # Enable STT
        identifier.enable_speech_to_text('google', 'en-US')
        
        try:
            # Test transcription
            transcription = identifier.transcribe_audio_file(test_file)
            print(f"Transcription result: {transcription}")
            
            if 'text' in transcription and transcription['text']:
                # Send transcription to ESP32 via TCP client
                if hasattr(identifier.esp32_client, 'send_transcription'):
                    success = identifier.esp32_client.send_transcription(
                        transcription['text'], 
                        transcription.get('confidence', 0.0)
                    )
                    if success:
                        print("✅ Transcription sent to ESP32")
                    else:
                        print("❌ Failed to send transcription to ESP32")
                else:
                    print("ℹ️ Transcription method not available in TCP client")
                    
                time.sleep(3)  # Extra time for transcription display
        except Exception as e:
            print(f"STT test failed: {e}")
    
    # Test 7: Connection status
    print("\n7️⃣ Final status check...")
    connected, status = identifier.get_esp32_status()
    print(f"ESP32 Status: {status}")
    
    # Cleanup
    print("\n🔚 Cleaning up...")
    identifier.disable_tcp_communication()
    
    print("\n✨ Test completed!")
    return True

def display_code_mappings():
    """
    Display the code mappings for ESP32
    """
    print("\n📋 ESP32 Code Mappings:")
    print("-" * 30)
    print("Person Codes:")
    print("  0 = Unknown/Default")
    print("  1 = Person 1 (hitendra)")
    print("  2 = Person 2")
    print("  3 = Person 3")
    print()
    print("Emotion Codes:")
    print("  0 = Neutral")
    print("  1 = Happy")
    print("  2 = Sad") 
    print("  3 = Angry")
    print("  4 = Calm")
    print("  5 = Excited")
    print()
    print("📡 Expected ESP32 Arduino Features:")
    print("  • WiFi TCP Server on port 8080")
    print("  • OLED Display (128x64) - GPIO 6 & 7")
    print("  • Haptic Motor - GPIO 13")
    print("  • LED Indicators")
    print("  • JSON & Simple format support")
    print("  • Speech-to-text display capability")
    print()

def test_individual_features():
    """
    Test individual ESP32 features separately
    """
    print("\n🔧 Individual Feature Tests")
    print("-" * 40)
    
    esp32_ip = "192.168.1.100"
    esp32_port = 8080
    identifier = VoiceIdentifier(esp32_ip, esp32_port)
    identifier.enable_tcp_communication()
    
    # Test connection first
    success, message = identifier.test_esp32_connection()
    if not success:
        print(f"❌ Cannot run individual tests - {message}")
        return False
    
    print("✅ Connection established - Running individual tests...\n")
    
    # Test 1: Person Code Display
    print("Test 1: Person Code Display")
    identifier.send_to_esp32("hitendra", "Neutral", 0.95, 0.80)
    time.sleep(3)
    
    # Test 2: Emotion Code Display  
    print("Test 2: Emotion Code Display")
    identifier.send_to_esp32("unknown", "Happy", 0.50, 0.90)
    time.sleep(3)
    
    # Test 3: High Confidence Display
    print("Test 3: High Confidence Display")
    identifier.send_to_esp32("person2", "Excited", 0.98, 0.95)
    time.sleep(3)
    
    # Test 4: Low Confidence Display
    print("Test 4: Low Confidence Display")  
    identifier.send_to_esp32("person3", "Sad", 0.45, 0.35)
    time.sleep(3)
    
    identifier.disable_tcp_communication()
    print("Individual feature tests completed ✅")
    return True

def main():
    """
    Main test function
    """
    print("ESP32 Voice Analysis Communication Test")
    print("=====================================")
    
    display_code_mappings()
    
    # Ask user what test to run
    print("Select test mode:")
    print("1. Full system test")
    print("2. Individual feature test")
    print("3. Both tests")
    
    try:
        choice = input("\nEnter choice (1-3) or press Enter for full test: ").strip()
        
        if choice == "2":
            success = test_individual_features()
        elif choice == "3":
            print("\n" + "="*50)
            print("Running Full System Test...")
            success1 = test_esp32_communication()
            
            print("\n" + "="*50) 
            print("Running Individual Feature Tests...")
            success2 = test_individual_features()
            
            success = success1 and success2
        else:  # Default to full test
            success = test_esp32_communication()
        
        if success:
            print("\n🎉 All tests completed successfully!")
            print("\n💡 Next Steps:")
            print("  • Verify ESP32 OLED display shows correct data")
            print("  • Check haptic feedback on GPIO 13")
            print("  • Test with real voice recordings")
            print("  • Monitor Serial output for debugging")
        else:
            print("\n⚠️ Some tests failed. Check ESP32 connection.")
            print("\n🔍 Troubleshooting:")
            print("  • Verify ESP32 IP address is correct")
            print("  • Check WiFi connection on ESP32")
            print("  • Ensure Arduino code is uploaded and running")
            print("  • Check Serial Monitor for ESP32 status")
            
    except KeyboardInterrupt:
        print("\n🛑 Test interrupted by user")
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
