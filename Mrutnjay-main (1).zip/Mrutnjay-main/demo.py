#!/usr/bin/env python3
"""
Voice Identifier Demo Script

This script demonstrates the basic functionality of the voice identification system.
It will guide you through collecting samples, training a model, and testing identification.
"""

import os
import sys
from voice_id import VoiceIdentifier
from voice_recorder import VoiceRecorder

def print_header(title):
    """Print a formatted header"""
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60)

def print_step(step_num, description):
    """Print a step in the process"""
    print(f"\n[Step {step_num}] {description}")
    print("-" * 40)

def demo_voice_identification():
    """
    Run a complete demo of the voice identification system
    """
    print_header("VOICE IDENTIFIER DEMO")
    print("This demo will walk you through the complete voice identification process.")
    print("\nWhat you'll do:")
    print("1. Record voice samples for 2-3 different speakers")
    print("2. Train a machine learning model")
    print("3. Test the model with new voice recordings")
    print("\nNote: You'll need a working microphone for this demo.")
    
    input("\nPress Enter to continue...")
    
    # Initialize components
    recorder = VoiceRecorder()
    identifier = VoiceIdentifier()
    
    # Step 1: Collect voice samples
    print_step(1, "Collecting Voice Samples")
    print("We'll collect voice samples for training the model.")
    print("For best results, use 2-3 different people with distinct voices.")
    
    speakers = []
    num_speakers = 0
    
    while True:
        speaker_name = input(f"\nEnter name for speaker {num_speakers + 1} (or 'done' to finish): ").strip()
        if speaker_name.lower() == 'done':
            if num_speakers < 2:
                print("Please add at least 2 speakers for meaningful training.")
                continue
            break
        
        if not speaker_name:
            print("Please enter a valid name.")
            continue
        
        speakers.append(speaker_name)
        print(f"\nCollecting 3 voice samples for {speaker_name}")
        print("Each recording will be 5 seconds long.")
        print("Try to speak naturally - you can read text, count numbers, or say anything.")
        
        try:
            recorder.collect_voice_samples(
                speaker_name=speaker_name,
                num_samples=3,
                sample_duration=5
            )
            num_speakers += 1
            print(f"✓ Samples collected for {speaker_name}")
        except KeyboardInterrupt:
            print("\nSample collection interrupted.")
            return
        except Exception as e:
            print(f"Error collecting samples: {e}")
            continue
    
    # Step 2: Train the model
    print_step(2, "Training the Voice Identification Model")
    print("Now we'll train a machine learning model using the collected samples.")
    
    if not os.path.exists("training_data"):
        print("Error: No training data found. Please collect samples first.")
        return
    
    try:
        print("Training in progress...")
        success = identifier.train_model("training_data")
        
        if success:
            print("✓ Model trained successfully!")
            
            # Save the model
            model_path = "demo_voice_model.pkl"
            identifier.save_model(model_path)
            print(f"✓ Model saved as {model_path}")
        else:
            print("✗ Training failed!")
            return
    except Exception as e:
        print(f"Error during training: {e}")
        return
    
    # Step 3: Test the model
    print_step(3, "Testing Voice Identification")
    print("Now let's test the trained model!")
    print("We'll record new voice samples and see if the model can identify the speakers.")
    
    while True:
        test_choice = input("\nWould you like to test the model? (y/n): ").strip().lower()
        if test_choice != 'y':
            break
        
        print("\nRecord a test sample (5 seconds):")
        input("Press Enter when ready to start recording...")
        
        try:
            test_file = f"test_recording_{len(os.listdir('.')) if os.path.exists('.') else 0}.wav"
            recorder.record_audio(duration=5, output_path=test_file)
            
            print("Analyzing the recording...")
            
            # Get detailed results
            results = identifier.identify_speaker(test_file, return_probabilities=True)
            
            if isinstance(results, str):
                print(f"Error: {results}")
            else:
                print("\n🎯 IDENTIFICATION RESULTS:")
                print("-" * 30)
                for i, (speaker, probability) in enumerate(results):
                    if i == 0:
                        print(f"🏆 BEST MATCH: {speaker} ({probability:.1%} confidence)")
                    else:
                        print(f"   {i+1}. {speaker}: {probability:.1%}")
                
                # Simple result
                speaker, confidence = identifier.identify_speaker(test_file)
                print(f"\n📊 Summary: Most likely speaker is '{speaker}' with {confidence:.1%} confidence")
            
        except KeyboardInterrupt:
            print("\nTesting interrupted.")
            break
        except Exception as e:
            print(f"Error during testing: {e}")
    
    # Demo completion
    print_header("DEMO COMPLETED")
    print("🎉 Congratulations! You've successfully:")
    print(f"   ✓ Collected voice samples for {len(speakers)} speakers")
    print("   ✓ Trained a voice identification model")
    print("   ✓ Tested the model with new recordings")
    
    print(f"\n📁 Files created:")
    print(f"   • training_data/ - Voice samples for training")
    print(f"   • demo_voice_model.pkl - Trained model")
    print(f"   • test_recording_*.wav - Test recordings")
    
    print(f"\n🚀 Next steps:")
    print(f"   • Try the GUI: python voice_app_gui.py")
    print(f"   • Use CLI: python voice_cli.py --help")
    print(f"   • Collect more samples for better accuracy")
    print(f"   • Read README.md for detailed documentation")

def main():
    """
    Main demo function
    """
    print("Voice Identifier Demo")
    print("=====================")
    
    # Check if required packages are available
    try:
        import librosa
        import pyaudio
        import sklearn
    except ImportError as e:
        print(f"Error: Missing required package: {e}")
        print("Please install requirements: pip install -r requirements.txt")
        return
    
    # Check for microphone
    try:
        import pyaudio
        p = pyaudio.PyAudio()
        if p.get_device_count() == 0:
            print("Error: No audio devices found. Please check your microphone.")
            return
        p.terminate()
    except Exception as e:
        print(f"Error accessing audio device: {e}")
        return
    
    try:
        demo_voice_identification()
    except KeyboardInterrupt:
        print("\n\nDemo interrupted by user. Goodbye!")
    except Exception as e:
        print(f"\nUnexpected error: {e}")
        print("Please check your setup and try again.")

if __name__ == "__main__":
    main()
