print("Starting minimal test...")

class VoiceIdentifier:
    def __init__(self):
        print("VoiceIdentifier created")

print("Class defined successfully")

if __name__ == "__main__":
    print("Running as main")
    vi = VoiceIdentifier()
    print("Done")
