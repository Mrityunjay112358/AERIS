#!/usr/bin/env python3
"""
Voice Identifier Command Line Interface

This script provides a command-line interface for the voice identification system.
It allows you to train models, collect voice samples, and identify speakers.
"""

import argparse
import os
import sys
from voice_id import VoiceIdentifier
from voice_recorder import VoiceRecorder

def train_model(args):
    """Train a voice identification model"""
    if not os.path.exists(args.data_folder):
        print(f"Error: Training data folder '{args.data_folder}' does not exist")
        return False
    
    identifier = VoiceIdentifier()
    print(f"Training model with data from: {args.data_folder}")
    
    success = identifier.train_model(args.data_folder)
    if success:
        # Create models directory if it doesn't exist
        models_dir = "models"
        os.makedirs(models_dir, exist_ok=True)
        
        # Use provided output path or default to models folder
        if args.output:
            output_path = args.output
        else:
            output_path = os.path.join(models_dir, "voice_model.pkl")
            
        identifier.save_model(output_path)
        print(f"Model saved to: {output_path}")
    
    return success

def identify_speaker(args):
    """Identify speaker from audio file"""
    if not os.path.exists(args.audio_file):
        print(f"Error: Audio file '{args.audio_file}' does not exist")
        return
    
    if not os.path.exists(args.model):
        print(f"Error: Model file '{args.model}' does not exist")
        return
    
    identifier = VoiceIdentifier()
    identifier.load_model(args.model)
    
    print(f"Identifying speaker from: {args.audio_file}")
    
    if args.detailed:
        results = identifier.identify_speaker(args.audio_file, return_probabilities=True)
        if isinstance(results, str):
            print(f"Error: {results}")
        else:
            print("\nDetailed Results:")
            print("-" * 40)
            for i, (speaker, probability) in enumerate(results):
                marker = "🏆" if i == 0 else f"{i+1}."
                print(f"{marker} {speaker}: {probability:.2%}")
    else:
        result = identifier.identify_speaker(args.audio_file)
        if isinstance(result, tuple):
            speaker, confidence = result
            print(f"Identified Speaker: {speaker}")
            print(f"Confidence: {confidence:.2%}")
        else:
            print(f"Error: {result}")

def collect_samples(args):
    """Collect voice samples for training"""
    recorder = VoiceRecorder()
    
    print(f"Collecting {args.num_samples} voice samples for '{args.speaker_name}'")
    print(f"Each sample will be {args.duration} seconds long")
    
    try:
        recorder.collect_voice_samples(
            speaker_name=args.speaker_name,
            num_samples=args.num_samples,
            sample_duration=args.duration
        )
        print("Voice sample collection completed!")
    except KeyboardInterrupt:
        print("\nCollection interrupted by user")
    except Exception as e:
        print(f"Error during collection: {e}")

def record_audio(args):
    """Record a single audio file"""
    recorder = VoiceRecorder()
    
    print(f"Recording {args.duration} seconds to '{args.output}'")
    try:
        recorder.record_audio(duration=args.duration, output_path=args.output)
        print("Recording completed!")
    except KeyboardInterrupt:
        print("\nRecording interrupted by user")
    except Exception as e:
        print(f"Error during recording: {e}")

def main():
    parser = argparse.ArgumentParser(
        description="Voice Identifier - Identify people through voice analysis",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Collect voice samples for training
  python voice_cli.py collect-samples --speaker-name "John Doe" --num-samples 5 --duration 5
  
  # Train a model
  python voice_cli.py train --data-folder training_data --output voice_model.pkl
  
  # Identify a speaker
  python voice_cli.py identify --audio-file test.wav --model voice_model.pkl
  
  # Record audio
  python voice_cli.py record --output my_recording.wav --duration 10
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Collect samples command
    collect_parser = subparsers.add_parser('collect-samples', help='Collect voice samples for training')
    collect_parser.add_argument('--speaker-name', required=True, help='Name of the speaker')
    collect_parser.add_argument('--num-samples', type=int, default=5, help='Number of samples to collect (default: 5)')
    collect_parser.add_argument('--duration', type=int, default=5, help='Duration of each sample in seconds (default: 5)')
    
    # Train command
    train_parser = subparsers.add_parser('train', help='Train a voice identification model')
    train_parser.add_argument('--data-folder', required=True, help='Folder containing training data')
    train_parser.add_argument('--output', help='Output file for the trained model')
    
    # Identify command
    identify_parser = subparsers.add_parser('identify', help='Identify speaker from audio file')
    identify_parser.add_argument('--audio-file', required=True, help='Audio file to analyze')
    identify_parser.add_argument('--model', required=True, help='Trained model file')
    identify_parser.add_argument('--detailed', action='store_true', help='Show detailed results with probabilities')
    
    # Record command
    record_parser = subparsers.add_parser('record', help='Record audio to file')
    record_parser.add_argument('--output', default='recording.wav', help='Output audio file (default: recording.wav)')
    record_parser.add_argument('--duration', type=int, default=5, help='Recording duration in seconds (default: 5)')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    try:
        if args.command == 'collect-samples':
            collect_samples(args)
        elif args.command == 'train':
            train_model(args)
        elif args.command == 'identify':
            identify_speaker(args)
        elif args.command == 'record':
            record_audio(args)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
