import numpy as np
import pickle
import os
import librosa
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

# Import mood analyzer
from voice_mood_simple import VoiceMoodAnalyzer
# Import TCP client for ESP32 communication
from tcp_client import ESP32TCPClient
# Import speech-to-text converter
from speech_to_text import SpeechToTextConverter

class VoiceIdentifier:
    def __init__(self, esp32_host="192.168.1.100", esp32_port=8080):
        self.model = None
        self.scaler = StandardScaler()
        self.speakers = {}
        self.feature_dim = None
        
        # Initialize mood analyzer
        self.mood_analyzer = VoiceMoodAnalyzer()
        
        # Initialize TCP client for ESP32
        self.esp32_client = ESP32TCPClient(esp32_host, esp32_port)
        self.tcp_enabled = False
        
        # Initialize speech-to-text converter
        self.speech_to_text = SpeechToTextConverter()
        self.stt_enabled = True
        self.stt_engine = 'google'  # default engine
        self.stt_language = 'en-US'  # default language
        
    def extract_features(self, audio_path, sr=22050):
        try:
            y, sr = librosa.load(audio_path, sr=sr)
            features = []
            
            # MFCC features
            mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
            features.extend(np.mean(mfccs, axis=1))
            features.extend(np.std(mfccs, axis=1))
            
            # Zero crossing rate
            zcr = librosa.feature.zero_crossing_rate(y)
            features.append(np.mean(zcr))
            features.append(np.std(zcr))
            
            # Spectral centroid
            centroid = librosa.feature.spectral_centroid(y=y, sr=sr)
            features.append(np.mean(centroid))
            features.append(np.std(centroid))
            
            # Spectral rolloff
            rolloff = librosa.feature.spectral_rolloff(y=y, sr=sr)
            features.append(np.mean(rolloff))
            features.append(np.std(rolloff))
            
            # RMS energy
            rms = librosa.feature.rms(y=y)
            features.append(np.mean(rms))
            features.append(np.std(rms))
            
            # Signal statistics
            features.extend([np.mean(y), np.std(y), np.max(y), np.min(y)])
            
            return np.array(features)
            
        except Exception as e:
            print(f"Error extracting features from {audio_path}: {e}")
            return None
    
    def train_model(self, data_folder):
        X = []
        y = []
        speaker_id = 0
        
        print("Extracting features from training data...")
        
        for speaker_folder in os.listdir(data_folder):
            speaker_path = os.path.join(data_folder, speaker_folder)
            if os.path.isdir(speaker_path):
                self.speakers[speaker_id] = speaker_folder
                print(f"Processing speaker: {speaker_folder}")
                
                for audio_file in os.listdir(speaker_path):
                    if audio_file.endswith(('.wav', '.mp3', '.flac', '.m4a')):
                        audio_path = os.path.join(speaker_path, audio_file)
                        features = self.extract_features(audio_path)
                        
                        if features is not None:
                            X.append(features)
                            y.append(speaker_id)
                            print(f"  ✓ Processed: {audio_file}")
                        else:
                            print(f"  ✗ Failed: {audio_file}")
                
                speaker_id += 1
        
        if len(X) == 0:
            print("No valid audio files found for training!")
            return False
        
        if len(self.speakers) < 2:
            print(f"Error: Need at least 2 speakers. Found {len(self.speakers)}")
            return False
        
        X = np.array(X)
        y = np.array(y)
        
        print(f"Training with {len(X)} samples from {len(self.speakers)} speakers")
        
        X_scaled = self.scaler.fit_transform(X)
        self.feature_dim = X_scaled.shape[1]
        
        if len(X) >= 4:
            X_train, X_test, y_train, y_test = train_test_split(
                X_scaled, y, test_size=0.2, random_state=42
            )
        else:
            X_train, X_test, y_train, y_test = X_scaled, X_scaled, y, y
        
        self.model = SVC(kernel='rbf', probability=True, random_state=42)
        self.model.fit(X_train, y_train)
        
        y_pred = self.model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        print(f"Model accuracy: {accuracy:.2%}")
        
        return True
    
    def identify_speaker(self, audio_path, return_probabilities=False):
        if self.model is None:
            return "Model not trained yet!"
        
        features = self.extract_features(audio_path)
        if features is None:
            return "Error processing audio file"
        
        if len(features) != self.feature_dim:
            return f"Feature dimension mismatch"
        
        features_scaled = self.scaler.transform([features])
        
        if return_probabilities:
            probabilities = self.model.predict_proba(features_scaled)[0]
            results = [(self.speakers[i], prob) for i, prob in enumerate(probabilities)]
            return sorted(results, key=lambda x: x[1], reverse=True)
        else:
            prediction = self.model.predict(features_scaled)[0]
            confidence = np.max(self.model.predict_proba(features_scaled))
            return self.speakers[prediction], confidence
    
    def save_model(self, model_path):
        model_data = {
            'model': self.model,
            'scaler': self.scaler,
            'speakers': self.speakers,
            'feature_dim': self.feature_dim
        }
        with open(model_path, 'wb') as f:
            pickle.dump(model_data, f)
        print(f"Model saved to {model_path}")
    
    def load_model(self, model_path):
        with open(model_path, 'rb') as f:
            model_data = pickle.load(f)
        
        self.model = model_data['model']
        self.scaler = model_data['scaler']
        self.speakers = model_data['speakers']
        self.feature_dim = model_data['feature_dim']
        print(f"Model loaded from {model_path}")
        print(f"Speakers: {list(self.speakers.values())}")
    
    def identify_speaker_with_mood(self, audio_path, return_probabilities=False):
        """
        Identify both speaker and mood from audio file
        """
        # Get speaker identification
        speaker_result = self.identify_speaker(audio_path, return_probabilities)
        
        # Get mood analysis
        try:
            mood_result = self.mood_analyzer.predict_mood(audio_path, return_probabilities)
        except Exception as e:
            mood_result = f"Mood analysis error: {e}"
        
        return {
            'speaker': speaker_result,
            'mood': mood_result
        }
    
    def analyze_audio_complete(self, audio_path):
        """
        Complete audio analysis including speaker identification and mood
        """
        if self.model is None:
            return "Model not trained yet!"
        
        try:
            # Speaker identification
            speaker, speaker_confidence = self.identify_speaker(audio_path)
            
            # Mood analysis
            mood, mood_confidence = self.mood_analyzer.predict_mood(audio_path)
            
            # Get detailed probabilities
            speaker_probs = self.identify_speaker(audio_path, return_probabilities=True)
            mood_probs = self.mood_analyzer.predict_mood(audio_path, return_probabilities=True)
            
            return {
                'speaker': {
                    'prediction': speaker,
                    'confidence': speaker_confidence,
                    'probabilities': speaker_probs if not isinstance(speaker_probs, str) else None
                },
                'mood': {
                    'prediction': mood,
                    'confidence': mood_confidence,
                    'probabilities': mood_probs if not isinstance(mood_probs, str) else None
                },
                'audio_file': audio_path
            }
        except Exception as e:
            return f"Analysis error: {e}"
    
    # TCP Communication Methods for ESP32
    def enable_tcp_communication(self, esp32_host=None, esp32_port=None):
        """
        Enable TCP communication with ESP32
        """
        if esp32_host:
            self.esp32_client.host = esp32_host
        if esp32_port:
            self.esp32_client.port = esp32_port
        
        self.tcp_enabled = True
        print(f"TCP communication enabled for ESP32 at {self.esp32_client.host}:{self.esp32_client.port}")
    
    def disable_tcp_communication(self):
        """
        Disable TCP communication with ESP32
        """
        self.tcp_enabled = False
        self.esp32_client.disconnect()
        print("TCP communication disabled")
    
    def test_esp32_connection(self):
        """
        Test connection to ESP32
        """
        if not self.tcp_enabled:
            return False, "TCP communication is disabled"
        
        success = self.esp32_client.test_connection()
        if success:
            return True, f"ESP32 connection successful at {self.esp32_client.host}:{self.esp32_client.port}"
        else:
            return False, f"ESP32 connection failed at {self.esp32_client.host}:{self.esp32_client.port}"
    
    def send_to_esp32(self, person_name, emotion_name, confidence_person=0.0, confidence_emotion=0.0):
        """
        Send analysis results to ESP32
        """
        if not self.tcp_enabled:
            print("TCP communication is disabled")
            return False
        
        try:
            success = self.esp32_client.send_analysis_result(
                person_name, emotion_name, 
                confidence_person, confidence_emotion
            )
            if success:
                print(f"Sent to ESP32: {person_name} (Person), {emotion_name} (Emotion)")
            else:
                print("Failed to send data to ESP32")
            return success
        except Exception as e:
            print(f"Error sending to ESP32: {e}")
            return False
    
    def analyze_and_send_to_esp32(self, audio_path):
        """
        Perform complete analysis and send results to ESP32
        """
        try:
            # Perform complete analysis
            results = self.analyze_audio_complete(audio_path)
            
            if isinstance(results, str):
                print(f"Analysis error: {results}")
                return False
            
            # Extract results
            speaker_data = results['speaker']
            mood_data = results['mood']
            
            person_name = speaker_data['prediction']
            emotion_name = mood_data['prediction']
            confidence_person = speaker_data['confidence']
            confidence_emotion = mood_data['confidence']
            
            # Send to ESP32 if TCP is enabled
            if self.tcp_enabled:
                success = self.send_to_esp32(person_name, emotion_name, confidence_person, confidence_emotion)
                if success:
                    print(f"Complete analysis sent to ESP32: {person_name} ({confidence_person:.1%}), {emotion_name} ({confidence_emotion:.1%})")
                return success
            else:
                print("TCP communication disabled - analysis complete but not sent to ESP32")
                return True
                
        except Exception as e:
            print(f"Error in analyze_and_send_to_esp32: {e}")
            return False
    
    def update_esp32_person_mapping(self, person_name, person_code):
        """
        Update person name to code mapping for ESP32
        """
        if 1 <= person_code <= 3:
            self.esp32_client.update_person_mapping(person_name, person_code)
            print(f"Updated ESP32 person mapping: {person_name} -> Code {person_code}")
        else:
            print("Person code must be between 1 and 3")
    
    def get_esp32_status(self):
        """
        Get ESP32 connection status
        """
        if not self.tcp_enabled:
            return False, "TCP communication disabled"
        
        return self.esp32_client.get_connection_status()
    
    # Speech-to-Text Methods
    def enable_speech_to_text(self, engine='google', language='en-US'):
        """
        Enable speech-to-text conversion
        
        Args:
            engine (str): Speech recognition engine ('google', 'sphinx', etc.)
            language (str): Language code (e.g., 'en-US', 'es-ES')
        """
        self.stt_enabled = True
        self.stt_engine = engine
        self.stt_language = language
        print(f"Speech-to-text enabled - Engine: {engine}, Language: {language}")
    
    def disable_speech_to_text(self):
        """Disable speech-to-text conversion"""
        self.stt_enabled = False
        print("Speech-to-text disabled")
    
    def transcribe_audio_file(self, audio_path):
        """
        Convert speech to text from audio file
        
        Args:
            audio_path (str): Path to audio file
            
        Returns:
            dict: Transcription results
        """
        if not self.stt_enabled:
            return {'error': 'Speech-to-text is disabled'}
        
        return self.speech_to_text.transcribe_audio(
            audio_path, 
            engine=self.stt_engine, 
            language=self.stt_language
        )
    
    def transcribe_microphone(self, duration=5):
        """
        Record from microphone and convert speech to text
        
        Args:
            duration (int): Recording duration in seconds
            
        Returns:
            dict: Transcription results
        """
        if not self.stt_enabled:
            return {'error': 'Speech-to-text is disabled'}
        
        return self.speech_to_text.transcribe_microphone(
            duration=duration,
            engine=self.stt_engine,
            language=self.stt_language
        )
    
    def analyze_with_transcription(self, audio_path):
        """
        Perform complete voice analysis including speech-to-text, speaker identification, and mood analysis
        
        Args:
            audio_path (str): Path to audio file
            
        Returns:
            dict: Complete analysis results including transcription
        """
        results = {
            'transcription': None,
            'speaker': None,
            'mood': None,
            'esp32_sent': False,
            'success': False
        }
        
        try:
            # 1. Speech-to-text conversion
            if self.stt_enabled:
                print("🔄 Converting speech to text...")
                transcription_result = self.transcribe_audio_file(audio_path)
                results['transcription'] = transcription_result
                
                if transcription_result['success']:
                    print(f"📝 Transcription: {transcription_result['transcription']}")
                    print(f"📊 Confidence: {transcription_result['confidence']:.1%}")
                else:
                    print(f"❌ Transcription failed: {transcription_result['error']}")
            
            # 2. Speaker identification
            if self.model:
                print("🔄 Identifying speaker...")
                speaker_raw = self.identify_speaker(audio_path)
                if isinstance(speaker_raw, tuple):
                    speaker_name, speaker_conf = speaker_raw
                    results['speaker'] = {
                        'prediction': speaker_name,
                        'confidence': speaker_conf
                    }
                    print(f"👤 Speaker: {speaker_name} ({speaker_conf:.1%})")
                else:
                    results['speaker'] = {'error': str(speaker_raw)}
            
            # 3. Mood analysis
            print("🔄 Analyzing emotion...")
            mood_raw = self.mood_analyzer.predict_mood(audio_path)
            if isinstance(mood_raw, tuple):
                mood_name, mood_conf = mood_raw
                results['mood'] = {
                    'prediction': mood_name,
                    'confidence': mood_conf
                }
                print(f"😊 Emotion: {mood_name} ({mood_conf:.1%})")
            else:
                results['mood'] = {'error': str(mood_raw)}
            
            # 4. Send to ESP32 if enabled
            if self.tcp_enabled and results['speaker'] and results['mood']:
                print("🔄 Sending data to ESP32...")
                esp32_success = self.send_to_esp32(
                    results['speaker']['prediction'],
                    results['mood']['prediction'],
                    results['speaker']['confidence'],
                    results['mood']['confidence']
                )
                results['esp32_sent'] = esp32_success
                
                if esp32_success:
                    print("✅ Data sent to ESP32 successfully")
                else:
                    print("❌ Failed to send data to ESP32")
            
            results['success'] = True
            return results
            
        except Exception as e:
            print(f"Error in complete analysis: {e}")
            results['error'] = str(e)
            return results
    
    def record_and_analyze_live(self, duration=5, include_transcription=True):
        """
        Record from microphone and perform live analysis
        
        Args:
            duration (int): Recording duration in seconds
            include_transcription (bool): Whether to include speech-to-text
            
        Returns:
            dict: Complete analysis results
        """
        results = {
            'transcription': None,
            'speaker': None,
            'mood': None,
            'esp32_sent': False,
            'success': False
        }
        
        try:
            print(f"🎤 Recording for {duration} seconds...")
            
            # Save to temporary file for analysis
            import tempfile
            temp_audio = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
            temp_path = temp_audio.name
            temp_audio.close()
            
            # Record audio
            from voice_recorder import VoiceRecorder
            recorder = VoiceRecorder()
            recorder.record_audio(duration=duration, output_path=temp_path)
            
            print("✅ Recording complete, analyzing...")
            
            # Perform complete analysis
            if include_transcription:
                results = self.analyze_with_transcription(temp_path)
            else:
                # Just speaker and mood analysis
                if self.model:
                    speaker_raw = self.identify_speaker(temp_path)
                    if isinstance(speaker_raw, tuple):
                        speaker_name, speaker_conf = speaker_raw
                        results['speaker'] = {
                            'prediction': speaker_name,
                            'confidence': speaker_conf
                        }
                    else:
                        results['speaker'] = {'error': str(speaker_raw)}
                        
                mood_raw = self.mood_analyzer.predict_mood(temp_path)
                if isinstance(mood_raw, tuple):
                    mood_name, mood_conf = mood_raw
                    results['mood'] = {
                        'prediction': mood_name,
                        'confidence': mood_conf
                    }
                else:
                    results['mood'] = {'error': str(mood_raw)}
                
                # Send to ESP32 if enabled
                if self.tcp_enabled and results['speaker'] and results['mood']:
                    results['esp32_sent'] = self.send_to_esp32(
                        results['speaker']['prediction'],
                        results['mood']['prediction'],
                        results['speaker']['confidence'],
                        results['mood']['confidence']
                    )
                
                results['success'] = True
            
            # Clean up temporary file
            try:
                os.unlink(temp_path)
            except:
                pass
                
            return results
            
        except Exception as e:
            print(f"Error in live analysis: {e}")
            results['error'] = str(e)
            return results
    
    def get_speech_to_text_status(self):
        """Get current speech-to-text configuration"""
        return {
            'enabled': self.stt_enabled,
            'engine': self.stt_engine,
            'language': self.stt_language,
            'supported_engines': self.speech_to_text.supported_engines,
            'supported_languages': self.speech_to_text.get_supported_languages()
        }
